import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Player, WeeklyPlan, DailyPlan, RealizedLog } from "./types";
import {
  INITIAL_PLAYERS,
  INITIAL_WEEKLY_PLANS,
  INITIAL_DAILY_PLANS,
  INITIAL_REALIZED_LOGS,
} from "./data";

// Import Views
import DashboardView from "./components/DashboardView";
import WeeklyPlanningView from "./components/WeeklyPlanningView";
import DailyPlanningView from "./components/DailyPlanningView";
import DailyRealizedView from "./components/DailyRealizedView";
import BiWeeklyTestView from "./components/BiWeeklyTestView";
import IsokineticTestView from "./components/IsokineticTestView";

// Import Icons
import {
  LayoutDashboard,
  CalendarDays,
  FileSpreadsheet,
  Zap,
  Activity,
  HeartPulse,
  UserPlus,
  Users,
  Calendar,
  RotateCcw,
  ShieldCheck,
  Plus,
  Menu,
  X,
} from "lucide-react";

export default function App() {
  // Load initial data from localStorage or fallback
  const [players, setPlayers] = useState<Player[]>(() => {
    const saved = localStorage.getItem("rtp_players");
    return saved ? JSON.parse(saved) : INITIAL_PLAYERS;
  });

  const [weeklyPlans, setWeeklyPlans] = useState<WeeklyPlan[]>(() => {
    const saved = localStorage.getItem("rtp_weekly_plans");
    return saved ? JSON.parse(saved) : INITIAL_WEEKLY_PLANS;
  });

  const [dailyPlans, setDailyPlans] = useState<DailyPlan[]>(() => {
    const saved = localStorage.getItem("rtp_daily_plans");
    return saved ? JSON.parse(saved) : INITIAL_DAILY_PLANS;
  });

  const [realizedLogs, setRealizedLogs] = useState<RealizedLog[]>(() => {
    const saved = localStorage.getItem("rtp_realized_logs");
    return saved ? JSON.parse(saved) : INITIAL_REALIZED_LOGS;
  });

  const [selectedPlayerId, setSelectedPlayerId] = useState<string>("p1");
  const [selectedDate, setSelectedDate] = useState<string>("2026-06-30");
  const [activeMenu, setActiveMenu] = useState<string>("dashboard");

  // Mobile menu toggle
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // New Player Name Form state
  const [newPlayerName, setNewPlayerName] = useState("");
  const [showAddPlayer, setShowAddPlayer] = useState(false);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem("rtp_players", JSON.stringify(players));
  }, [players]);

  useEffect(() => {
    localStorage.setItem("rtp_weekly_plans", JSON.stringify(weeklyPlans));
  }, [weeklyPlans]);

  useEffect(() => {
    localStorage.setItem("rtp_daily_plans", JSON.stringify(dailyPlans));
  }, [dailyPlans]);

  useEffect(() => {
    localStorage.setItem("rtp_realized_logs", JSON.stringify(realizedLogs));
  }, [realizedLogs]);

  // Selected Player details
  const selectedPlayer = players.find((p) => p.id === selectedPlayerId) || players[0];

  // System State Actions
  const handleUpdatePlayerMetrics = (playerId: string, metrics: Partial<Player>) => {
    setPlayers((prev) =>
      prev.map((p) => (p.id === playerId ? { ...p, ...metrics } : p))
    );
  };

  const handleAddWeeklyPlan = (plan: Omit<WeeklyPlan, "id" | "createdAt">) => {
    const newPlan: WeeklyPlan = {
      ...plan,
      id: "wp_" + Date.now(),
      createdAt: new Date().toISOString(),
    };
    setWeeklyPlans((prev) => [newPlan, ...prev]);
  };

  const handleDeleteWeeklyPlan = (id: string) => {
    setWeeklyPlans((prev) => prev.filter((p) => p.id !== id));
  };

  const handleAddDailyPlan = (plan: Omit<DailyPlan, "id">) => {
    const newPlan: DailyPlan = {
      ...plan,
      id: "dp_" + Date.now(),
    };
    setDailyPlans((prev) => [newPlan, ...prev]);
  };

  const handleDeleteDailyPlan = (id: string) => {
    setDailyPlans((prev) => prev.filter((p) => p.id !== id));
  };

  const handleAddRealizedLog = (log: Omit<RealizedLog, "id" | "createdAt">) => {
    const newLog: RealizedLog = {
      ...log,
      id: "rl_" + Date.now(),
      createdAt: new Date().toISOString(),
    };
    setRealizedLogs((prev) => [newLog, ...prev]);

    // Also update the player's core metrics based on this log!
    handleUpdatePlayerMetrics(log.playerId, {
      rtpStage: log.rtpStage,
      vasPain: log.vasPain,
    });
  };

  const handleDeleteRealizedLog = (id: string) => {
    setRealizedLogs((prev) => prev.filter((l) => l.id !== id));
  };

  const handleAddPlayer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPlayerName.trim()) return;

    const newPlayer: Player = {
      id: "p_" + Date.now(),
      name: newPlayerName.trim(),
      rtpStage: "Aşama 1: Klinik",
      vasPain: 0,
      asymmetry: 5.0,
      hqRatio: 0.60,
      nordbordDrop: 5.0,

      // PDF device metrics defaults
      rsi_modified: 0.40,
      ecc_decel_impulse_asym: 5.0,
      rfd_0_200ms: 5000,
      nordbord_peak_force_asym: 5.0,
      nordbord_peak_force_total: 350,
      add_abd_ratio: 1.05,
      groin_peak_force_asym: 5.0,
      hq_ratio_60: 0.60,
      quad_peak_torque_bw: 3.1,

      eccentricBrakingAsymmetry: 5.0,
      rsiModified: 0.40,
      hamstringAsymmetry: 5.0,
      hamstringPeakForce: 350,
      adductionsAbductionsRatio: 1.05,
      quadricepsPeakTorque: 200,
      hamstringPeakTorque: 120,
    };

    setPlayers((prev) => [...prev, newPlayer]);
    setSelectedPlayerId(newPlayer.id);
    setNewPlayerName("");
    setShowAddPlayer(false);
  };

  const handleResetSystem = () => {
    if (window.confirm("Tüm verileri ilk kurulum ayarlarına döndürmek istediğinize emin misiniz?")) {
      localStorage.removeItem("rtp_players");
      localStorage.removeItem("rtp_weekly_plans");
      localStorage.removeItem("rtp_daily_plans");
      localStorage.removeItem("rtp_realized_logs");
      setPlayers(INITIAL_PLAYERS);
      setWeeklyPlans(INITIAL_WEEKLY_PLANS);
      setDailyPlans(INITIAL_DAILY_PLANS);
      setRealizedLogs(INITIAL_REALIZED_LOGS);
      setSelectedPlayerId("p1");
      setActiveMenu("dashboard");
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans" id="app-viewport">
      {/* Upper Navigation Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-xs" id="app-header">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-slate-500 hover:text-slate-700 rounded-lg"
              id="mobile-menu-btn"
            >
              {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
            <div className="flex items-center gap-2.5">
              <span className="text-2xl">🏥</span>
              <div>
                <h1 className="text-base sm:text-lg font-extrabold text-slate-900 tracking-tight leading-tight">
                  Tesis Performans, Planlama & RTP Yönetim Sistemi
                </h1>
                <span className="text-[10px] font-mono text-slate-500 font-semibold block">
                  İzokinetik, ForceDecks, NordBord ve Periyotlama Entegrasyonu
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleResetSystem}
              className="flex items-center gap-1 px-2.5 py-1.5 text-[11px] font-bold text-slate-500 hover:text-rose-600 bg-slate-100 hover:bg-rose-50 rounded-lg transition border border-transparent hover:border-rose-100 cursor-pointer"
              title="Tüm verileri sıfırla"
            >
              <RotateCcw size={12} />
              <span className="hidden sm:inline">Sistemi Sıfırla</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Workspace */}
      <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 flex-1 flex flex-col lg:flex-row gap-6">
        {/* Left Sidebar (Desktop Navigation) */}
        <aside
          className={`w-full lg:w-72 shrink-0 space-y-6 lg:block ${
            mobileMenuOpen ? "block" : "hidden"
          }`}
          id="app-sidebar"
        >
          {/* Active Player Select Box */}
          <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs space-y-4">
            <div className="flex justify-between items-center">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                <Users size={14} className="text-slate-400" />
                Oyuncu Seçimi
              </label>
              <button
                onClick={() => setShowAddPlayer(!showAddPlayer)}
                className="text-xs text-indigo-600 hover:text-indigo-800 font-bold flex items-center gap-0.5"
              >
                <Plus size={12} />
                Yeni Ekle
              </button>
            </div>

            {showAddPlayer ? (
              <form onSubmit={handleAddPlayer} className="space-y-2 pt-1 animate-fade-in">
                <input
                  type="text"
                  placeholder="Oyuncu Adı Soyadı..."
                  value={newPlayerName}
                  onChange={(e) => setNewPlayerName(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-2 focus:outline-hidden focus:border-indigo-500"
                  required
                  autoFocus
                />
                <div className="flex gap-2 justify-end">
                  <button
                    type="button"
                    onClick={() => setShowAddPlayer(false)}
                    className="text-[10px] text-slate-500 font-bold px-2 py-1 hover:bg-slate-100 rounded"
                  >
                    Vazgeç
                  </button>
                  <button
                    type="submit"
                    className="text-[10px] bg-indigo-600 text-white font-bold px-3 py-1 rounded hover:bg-indigo-700 transition"
                  >
                    Kaydet
                  </button>
                </div>
              </form>
            ) : null}

            <div className="relative">
              <select
                value={selectedPlayerId}
                onChange={(e) => {
                  setSelectedPlayerId(e.target.value);
                  setMobileMenuOpen(false); // Close mobile sidebar if open
                }}
                className="w-full text-sm font-bold text-slate-800 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 appearance-none focus:outline-hidden focus:border-indigo-500 cursor-pointer"
              >
                {players.map((p) => (
                  <option key={p.id} value={p.id}>
                    👤 {p.name}
                  </option>
                ))}
              </select>
              <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400 text-xs">
                ▼
              </div>
            </div>

            {/* Quick Summary of selected player stage */}
            <div className="bg-slate-50/70 p-3 rounded-xl border border-slate-100/80 text-center space-y-1">
              <span className="text-[10px] text-slate-400 font-semibold block uppercase">Mevcut Durum</span>
              <span className="text-xs font-bold text-slate-700 block bg-white border border-slate-200/50 py-1 px-2.5 rounded shadow-2xs">
                {selectedPlayer.rtpStage}
              </span>
            </div>
          </div>

          {/* Date Selector */}
          <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs space-y-3">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
              <Calendar size={14} className="text-slate-400" />
              Sistem Tarihi
            </label>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-full text-xs font-bold font-mono text-slate-700 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-2 focus:outline-hidden focus:border-indigo-500"
            />
          </div>

          {/* Main Action Menu Nav */}
          <nav className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs space-y-1" id="action-menu-nav">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block px-2.5 pb-2">📋 İŞLEMLER</span>
            
            <button
              onClick={() => {
                setActiveMenu("dashboard");
                setMobileMenuOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition text-left cursor-pointer ${
                activeMenu === "dashboard"
                  ? "bg-slate-900 text-white shadow-xs"
                  : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
              }`}
            >
              <LayoutDashboard size={16} />
              1️⃣ Ana Panel (Dashboard)
            </button>

            <button
              onClick={() => {
                setActiveMenu("weekly");
                setMobileMenuOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition text-left cursor-pointer ${
                activeMenu === "weekly"
                  ? "bg-slate-900 text-white shadow-xs"
                  : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
              }`}
            >
              <CalendarDays size={16} />
              2️⃣ Haftalık Planlama 🗓️
            </button>

            <button
              onClick={() => {
                setActiveMenu("daily");
                setMobileMenuOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition text-left cursor-pointer ${
                activeMenu === "daily"
                  ? "bg-slate-900 text-white shadow-xs"
                  : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
              }`}
            >
              <FileSpreadsheet size={16} />
              3️⃣ Günlük İdman Planlama 📝
            </button>

            <button
              onClick={() => {
                setActiveMenu("realized");
                setMobileMenuOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition text-left cursor-pointer ${
                activeMenu === "realized"
                  ? "bg-slate-900 text-white shadow-xs"
                  : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
              }`}
            >
              <Zap size={16} />
              4️⃣ Günlük Yük Girişi 🏃‍♂️
            </button>

            <button
              onClick={() => {
                setActiveMenu("biweekly");
                setMobileMenuOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition text-left cursor-pointer ${
                activeMenu === "biweekly"
                  ? "bg-slate-900 text-white shadow-xs"
                  : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
              }`}
            >
              <HeartPulse size={16} />
              5️⃣ Haftalık Nöromüsküler Batarya 🗓️
            </button>

            <button
              onClick={() => {
                setActiveMenu("isokinetic");
                setMobileMenuOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition text-left cursor-pointer ${
                activeMenu === "isokinetic"
                  ? "bg-slate-900 text-white shadow-xs"
                  : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
              }`}
            >
              <Activity size={16} />
              6️⃣ Aylık İzokinetik Test 🔬
            </button>
          </nav>
        </aside>

        {/* Right Main Content Panel */}
        <main className="flex-1 min-w-0">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeMenu + "_" + selectedPlayerId}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.18, ease: "easeOut" }}
              className="space-y-6"
            >
              {activeMenu === "dashboard" && (
                <DashboardView
                  selectedPlayer={selectedPlayer}
                  weeklyPlans={weeklyPlans}
                  dailyPlans={dailyPlans}
                  realizedLogs={realizedLogs}
                  onUpdatePlayerMetrics={handleUpdatePlayerMetrics}
                />
              )}

              {activeMenu === "weekly" && (
                <WeeklyPlanningView
                  selectedPlayer={selectedPlayer}
                  weeklyPlans={weeklyPlans}
                  onAddWeeklyPlan={handleAddWeeklyPlan}
                  onDeleteWeeklyPlan={handleDeleteWeeklyPlan}
                />
              )}

              {activeMenu === "daily" && (
                <DailyPlanningView
                  selectedPlayer={selectedPlayer}
                  dailyPlans={dailyPlans}
                  onAddDailyPlan={handleAddDailyPlan}
                  onDeleteDailyPlan={handleDeleteDailyPlan}
                  selectedDate={selectedDate}
                />
              )}

              {activeMenu === "realized" && (
                <DailyRealizedView
                  selectedPlayer={selectedPlayer}
                  realizedLogs={realizedLogs}
                  onAddRealizedLog={handleAddRealizedLog}
                  onDeleteRealizedLog={handleDeleteRealizedLog}
                  selectedDate={selectedDate}
                />
              )}

              {activeMenu === "biweekly" && (
                <BiWeeklyTestView
                  selectedPlayer={selectedPlayer}
                  onUpdatePlayerMetrics={handleUpdatePlayerMetrics}
                />
              )}

              {activeMenu === "isokinetic" && (
                <IsokineticTestView
                  selectedPlayer={selectedPlayer}
                  onUpdatePlayerMetrics={handleUpdatePlayerMetrics}
                />
              )}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 text-center text-xs text-slate-400 mt-auto">
        <div className="max-w-7xl mx-auto px-4">
          © 2026 Tesis Performans, Planlama & RTP Yönetim Sistemi. Tüm hakları saklıdır.
          <span className="mx-2">|</span>
          ForceDecks, NordBord ve İzokinetik Dinamometre Lisanslı Entegre Sistem Yazılımı.
        </div>
      </footer>
    </div>
  );
}
