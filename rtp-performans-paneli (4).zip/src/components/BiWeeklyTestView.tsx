import React, { useState, useEffect } from "react";
import { Player } from "../types";
import { 
  Scale, 
  Save, 
  Zap, 
  HeartPulse, 
  CheckCircle2, 
  Activity, 
  TrendingUp, 
  AlertTriangle, 
  User, 
  ShieldAlert, 
  Sparkles,
  Percent,
  Atom,
  ChevronRight,
  ShieldCheck,
  CalendarDays,
  Gauge
} from "lucide-react";

interface BiWeeklyTestViewProps {
  selectedPlayer: Player;
  onUpdatePlayerMetrics: (playerId: string, metrics: Partial<Player>) => void;
}

export default function BiWeeklyTestView({
  selectedPlayer,
  onUpdatePlayerMetrics,
}: BiWeeklyTestViewProps) {
  // --- 1) TIMING / SCHEDULE PROFILE ---
  const [testTiming, setTestTiming] = useState<"MD-2" | "MD+2">("MD-2");

  // --- 2) REFERENCE BASELINE STATES (GEÇEN HAFTAKİ / BAZAL ARALIK) ---
  const [baseRsiMod, setBaseRsiMod] = useState(0.48);
  const [basePeakPower, setBasePeakPower] = useState(53.0); // W/kg
  const [baseCmjAsym, setBaseCmjAsym] = useState(6.5); // %

  const [baseAddForce, setBaseAddForce] = useState(490); // N (Total Adduction Force)
  const [baseGroinAsym, setBaseGroinAsym] = useState(5.5); // %

  const [baseNbForce, setBaseNbForce] = useState(380); // N (Total Hamstring Force)
  const [baseNbAsym, setBaseNbAsym] = useState(6.0); // %

  // --- 3) TODAY'S MEASUREMENTS (BUGÜNKÜ HAM ÖLÇÜMLER) ---
  // ForceDecks CMJ (MSS & Patlayıcılık)
  const [flightTime, setFlightTime] = useState(540); // ms
  const [contractionTime, setContractionTime] = useState(1080); // ms
  const [peakPower, setPeakPower] = useState(51.5); // W/kg
  const [leftCmjImpulse, setLeftCmjImpulse] = useState(115); // Ns
  const [rightCmjImpulse, setRightCmjImpulse] = useState(128); // Ns

  // ForceFrame Groin Squeeze (Kasık Kuvveti)
  const [leftAddForce, setLeftAddForce] = useState(235); // N
  const [rightAddForce, setRightAddForce] = useState(245); // N
  const [leftAbdForce, setLeftAbdForce] = useState(220); // N
  const [rightAbdForce, setRightAbdForce] = useState(230); // N

  // NordBord Nordic Hamstring (Arka Zincir)
  const [leftNbForce, setLeftNbForce] = useState(180); // N
  const [rightNbForce, setRightNbForce] = useState(190); // N

  const [successMsg, setSuccessMsg] = useState("");

  // Sync state with selectedPlayer baseline values on mount or selection change
  useEffect(() => {
    // ForceDecks Baseline Defaults
    setBaseRsiMod(selectedPlayer.rsi_modified || selectedPlayer.rsiModified || 0.48);
    setBasePeakPower(53.0);
    setBaseCmjAsym(selectedPlayer.ecc_decel_impulse_asym || selectedPlayer.eccentricBrakingAsymmetry || 6.5);

    // ForceFrame Baseline Defaults
    setBaseAddForce(490);
    setBaseGroinAsym(selectedPlayer.groin_peak_force_asym || 5.5);

    // NordBord Baseline Defaults
    setBaseNbForce(selectedPlayer.nordbord_peak_force_total || selectedPlayer.hamstringPeakForce || 380);
    setBaseNbAsym(selectedPlayer.nordbord_peak_force_asym || selectedPlayer.hamstringAsymmetry || 6.0);

    // Today's estimate starting points based on baseline
    setFlightTime(540);
    setContractionTime(1080);
    setPeakPower(51.5);
    setLeftCmjImpulse(115);
    setRightCmjImpulse(Math.round(115 * (1 + (selectedPlayer.ecc_decel_impulse_asym || 6.5) / 100)));

    setLeftAddForce(235);
    setRightAddForce(Math.round(235 * (1 + (selectedPlayer.groin_peak_force_asym || 5.5) / 100)));
    setLeftAbdForce(220);
    setRightAbdForce(225);

    setLeftNbForce(180);
    setRightNbForce(Math.round(180 * (1 + (selectedPlayer.nordbord_peak_force_asym || 6.0) / 100)));
  }, [selectedPlayer]);

  // --- LIVE MATH CALCULATIONS & RATIOS ---

  // Station 1: ForceDecks
  const calculatedRsiMod = parseFloat((flightTime / contractionTime).toFixed(2)) || 0;
  const rsiMaxImpulse = Math.max(leftCmjImpulse, rightCmjImpulse);
  const calculatedAsymFD = rsiMaxImpulse > 0 ? parseFloat((Math.abs(leftCmjImpulse - rightCmjImpulse) / rsiMaxImpulse * 100).toFixed(1)) : 0;
  const rsiDropPct = parseFloat((((baseRsiMod - calculatedRsiMod) / baseRsiMod) * 100).toFixed(1)) || 0;
  const peakPowerDropPct = parseFloat((((basePeakPower - peakPower) / basePeakPower) * 100).toFixed(1)) || 0;

  // Station 2: ForceFrame
  const calculatedAddForceTotal = leftAddForce + rightAddForce;
  const calculatedAbdForceTotal = leftAbdForce + rightAbdForce;
  const calculatedAddAbdRatio = calculatedAbdForceTotal > 0 ? parseFloat((calculatedAddForceTotal / calculatedAbdForceTotal).toFixed(2)) : 0;
  const maxAdd = Math.max(leftAddForce, rightAddForce);
  const calculatedAsymFF = maxAdd > 0 ? parseFloat((Math.abs(leftAddForce - rightAddForce) / maxAdd * 100).toFixed(1)) : 0;
  const groinForceDropPct = parseFloat((((baseAddForce - calculatedAddForceTotal) / baseAddForce) * 100).toFixed(1)) || 0;

  // Station 3: NordBord
  const calculatedNbTotal = leftNbForce + rightNbForce;
  const maxNb = Math.max(leftNbForce, rightNbForce);
  const calculatedAsymNB = maxNb > 0 ? parseFloat((Math.abs(leftNbForce - rightNbForce) / maxNb * 100).toFixed(1)) : 0;
  const nbForceDropPct = parseFloat((((baseNbForce - calculatedNbTotal) / baseNbForce) * 100).toFixed(1)) || 0;

  // --- ⚙️ HAFTALIK KARAR AĞACI ALGORİTMASI (WEEKLY DECISION TREE) ---
  const evaluateDecision = () => {
    const reasons: string[] = [];
    let state: "green" | "yellow" | "red" = "green";

    // 🔴 RED LIGHT (Kırmızı - Tehlike)
    // Rule: Asimetriler > %15 VEYA herhangi bir tepe kuvvette (NordBord/ForceFrame) > %15 düşüş.
    const hasRedAsymmetry = calculatedAsymFD > 15 || calculatedAsymFF > 15 || calculatedAsymNB > 15;
    const hasRedForceDrop = groinForceDropPct > 15 || nbForceDropPct > 15;

    if (calculatedAsymFD > 15) reasons.push(`ForceDecks CMJ Frenleme Asimetrisi (%${calculatedAsymFD}) tehlikeli limitin (> %15) üzerinde.`);
    if (calculatedAsymFF > 15) reasons.push(`ForceFrame Kasık Sıkıştırma Asimetrisi (%${calculatedAsymFF}) tehlikeli limitin (> %15) üzerinde.`);
    if (calculatedAsymNB > 15) reasons.push(`NordBord Arka Zincir Asimetrisi (%${calculatedAsymNB}) tehlikeli limitin (> %15) üzerinde.`);
    if (groinForceDropPct > 15) reasons.push(`ForceFrame Kasık Sıkıştırma Kuvveti geçen haftaya göre %${groinForceDropPct} düştü (Kritik Eşik: > %15).`);
    if (nbForceDropPct > 15) reasons.push(`NordBord Hamstring Tepe Kuvveti geçen haftaya göre %${nbForceDropPct} düştü (Kritik Eşik: > %15).`);

    if (hasRedAsymmetry || hasRedForceDrop) {
      state = "red";
      return {
        light: "red" as const,
        status: "🔴 KIRMIZI IŞIK (Tehlike / Yüksek Risk)",
        action: "Oyuncu yüksek risk altındadır! Sahadaki yüksek şiddetli koşular (HSR) ve patlayıcı tüm hareketler derhal durdurulmalı; oyuncu derhal klinik fizyoterapi, lokal manuel terapi ve yoğun rejenerasyon protokolüne sevk edilmelidir.",
        color: "bg-rose-50 border-rose-200 text-rose-900",
        badgeColor: "bg-rose-600 text-white animate-pulse",
        reasons
      };
    }

    // 🟡 YELLOW LIGHT (Sarı - Dikkat - Modifiye Et)
    // Rule: ForceDecks RSI değerinde > %7 düşüş VEYA ForceFrame kasık kuvvetinde > %10 düşüş.
    const hasYellowRsiDrop = rsiDropPct > 7;
    const hasYellowGroinDrop = groinForceDropPct > 10;

    if (rsiDropPct > 7) reasons.push(`ForceDecks RSI-Modified değerinde %${rsiDropPct} düşüş tespit edildi (Eşik: > %7). MSS yorgunluğu mevcut.`);
    if (groinForceDropPct > 10) reasons.push(`ForceFrame Kasık Sıkıştırma Kuvvetinde %${groinForceDropPct} düşüş var (Eşik: > %10). Pelvik stabilite zayıflamış.`);

    if (hasYellowRsiDrop || hasYellowGroinDrop) {
      state = "yellow";
      return {
        light: "yellow" as const,
        status: "🟡 SARI IŞIK (Dikkat - Antrenman Modifikasyonu)",
        action: "Dikkat! Nöromüsküler sistem yorgun veya kasık toleransı zayıf. Oyuncunun bugünkü sahadaki toplam koşu mesafesi (Total Distance) %15-20 oranında kısıtlanmalı, yüksek hızlı koşular (HSR) sınırlandırılmalı ve kuvvet seansında nöromüsküler aktivasyon/stabilizasyon drillerine odaklanılmalıdır.",
        color: "bg-amber-50 border-amber-200 text-amber-900",
        badgeColor: "bg-amber-500 text-slate-950",
        reasons
      };
    }

    // 🟢 GREEN LIGHT (Yeşil - Oyna ve Yükle)
    // Rule: Tüm asimetriler < %10, RSI ve Kuvvet değerleri geçen haftaki bazal değere eşit veya yüksek (ya da düşüşler yeşil sınırlarda).
    reasons.push("Tüm eklem ve kas grubu asimetrileri koruyucu limitler dahilindedir (< %10.0).");
    reasons.push("Merkezi sinir sistemi reaktif indeksleri (RSI Modified) geçen haftaki taze durumla uyumludur.");
    reasons.push("NordBord ve ForceFrame kasık-hamstring doku toleransı tam seviyededir.");

    return {
      light: "green" as const,
      status: "🟢 YEŞİL IŞIK (Oyna ve Güvenle Yükle)",
      action: "Tüm sistemler kararlı! Oyuncu bugünkü takım antrenmanına %100 kapasiteyle katılabilir. Planlanan antrenman periyotlamasına ve tam hacimli dış yüklere eksiksiz izin verilir.",
      color: "bg-emerald-50 border-emerald-200 text-emerald-900",
      badgeColor: "bg-emerald-600 text-white",
      reasons
    };
  };

  const decision = evaluateDecision();

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();

    // Persist calculated data onto the player object so it updates globally!
    onUpdatePlayerMetrics(selectedPlayer.id, {
      asymmetry: calculatedAsymFD, // Maps CMJ asymmetry
      ecc_decel_impulse_asym: calculatedAsymFD,
      eccentricBrakingAsymmetry: calculatedAsymFD,
      
      rsiModified: calculatedRsiMod,
      rsi_modified: calculatedRsiMod,
      
      nordbord_peak_force_asym: calculatedAsymNB,
      hamstringAsymmetry: calculatedAsymNB,
      nordbord_peak_force_total: calculatedNbTotal,
      hamstringPeakForce: calculatedNbTotal,
      nordbordDrop: nbForceDropPct, // Update current drop metric
      
      add_abd_ratio: calculatedAddAbdRatio,
      adductionsAbductionsRatio: calculatedAddAbdRatio,
      groin_peak_force_asym: calculatedAsymFF,
    });

    setSuccessMsg(`Haftalık Nöromüsküler Batarya verileri başarıyla kaydedildi. Karar: ${decision.status}. Sporcu profili güncellendi.`);
    window.scrollTo({ top: 0, behavior: "smooth" });
    setTimeout(() => setSuccessMsg(""), 6000);
  };

  return (
    <div className="space-y-6" id="weekly-neuromuscular-battery-root">
      {/* 1. Header Information */}
      <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-xs flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="flex h-2.5 w-2.5 rounded-full bg-indigo-600 animate-pulse" />
            <span className="text-xs font-black text-indigo-600 uppercase tracking-widest font-mono">MD-2 / MD+2 PROTOKOLÜ</span>
          </div>
          <h2 className="text-xl font-black text-slate-800 flex items-center gap-2">
            <CalendarDays className="text-indigo-600 h-6 w-6" />
            🗓️ Haftalık Nöromüsküler Yük Takibi Bataryası
          </h2>
          <p className="text-xs text-slate-500 max-w-3xl leading-relaxed">
            Takımdaki en stabil günde (ideal olarak <strong>MD-2</strong> veya <strong>MD+2</strong> sabahı) Gym Aktivasyon seansının ilk 10 dakikasında uygulanan 3 istasyonlu (CMJ → Squeeze → Nordic) bütünsel takip paneli.
          </p>
        </div>
        
        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <div className="bg-indigo-50 text-indigo-800 text-xs font-bold px-3.5 py-2 rounded-xl border border-indigo-100 flex items-center gap-1.5">
            <User size={14} />
            <span>Oyuncu: {selectedPlayer.name}</span>
          </div>

          <div className="bg-slate-100 border border-slate-200 rounded-xl p-1 flex">
            <button
              type="button"
              onClick={() => setTestTiming("MD-2")}
              className={`px-3 py-1 text-xs font-extrabold rounded-lg transition cursor-pointer ${testTiming === "MD-2" ? "bg-white text-slate-900 shadow-2xs" : "text-slate-500 hover:text-slate-700"}`}
            >
              MD-2 (Maç -2)
            </button>
            <button
              type="button"
              onClick={() => setTestTiming("MD+2")}
              className={`px-3 py-1 text-xs font-extrabold rounded-lg transition cursor-pointer ${testTiming === "MD+2" ? "bg-white text-slate-900 shadow-2xs" : "text-slate-500 hover:text-slate-700"}`}
            >
              MD+2 (Maç +2)
            </button>
          </div>
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {successMsg && (
          <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold p-4.5 rounded-xl animate-fade-in flex items-center gap-2">
            <CheckCircle2 size={18} className="text-emerald-600 shrink-0 animate-bounce" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* 2. MAIN DECISION TREE TRAFFIC LIGHT CARD (LIVE INTERACTIVE) */}
        <div className={`border-2 p-6 rounded-2xl transition-all duration-300 shadow-sm ${decision.color}`} id="live-decision-tree-box">
          <div className="flex items-start gap-4 flex-col sm:flex-row">
            <div className="p-3 bg-white rounded-2xl shadow-xs shrink-0 flex items-center justify-center border border-slate-100">
              <div className="flex flex-col gap-1.5 items-center">
                <span className={`h-5 w-5 rounded-full border-2 border-slate-350 ${decision.light === "red" ? "bg-rose-600 shadow-[0_0_12px_rgba(225,29,72,0.6)]" : "bg-slate-200"}`} />
                <span className={`h-5 w-5 rounded-full border-2 border-slate-350 ${decision.light === "yellow" ? "bg-amber-400 shadow-[0_0_12px_rgba(251,191,36,0.6)]" : "bg-slate-200"}`} />
                <span className={`h-5 w-5 rounded-full border-2 border-slate-350 ${decision.light === "green" ? "bg-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.6)]" : "bg-slate-200"}`} />
              </div>
            </div>

            <div className="space-y-3 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className={`text-[10px] uppercase font-black px-3.5 py-1.5 rounded-xl ${decision.badgeColor} shadow-2xs tracking-wide`}>
                  {decision.status}
                </span>
                <span className="font-extrabold text-xs text-slate-500 uppercase tracking-widest font-mono">HAFTALIK KARAR DESTEK SİSTEMİ</span>
              </div>
              
              <div className="space-y-1.5">
                <h3 className="font-black text-slate-900 text-base leading-snug">Algoritmik Antrenman Aksiyonu:</h3>
                <p className="text-sm font-bold text-slate-800 leading-relaxed bg-white/65 p-3.5 rounded-xl border border-white/40">
                  {decision.action}
                </p>
              </div>

              {/* Dynamic triggers display */}
              <div className="pt-2">
                <span className="text-[10px] font-black text-slate-500 uppercase tracking-wider block mb-1.5">Karar Verme Gerekçeleri (Tetikleyiciler):</span>
                <ul className="space-y-1 text-xs font-semibold text-slate-700">
                  {decision.reasons.map((r, i) => (
                    <li key={i} className="flex items-center gap-2">
                      <ChevronRight size={14} className="text-slate-400 shrink-0" />
                      <span>{r}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* 3. STATIONS INPUT & RATIO ANALYSIS */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          
          {/* STATION 1: FORCE_DECKS CMJ */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xs flex flex-col justify-between overflow-hidden">
            <div className="p-5 border-b border-slate-100 bg-slate-50/50">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider">İSTASYON 1</span>
                <span className="bg-amber-50 text-amber-700 border border-amber-100 text-[9px] font-mono font-bold px-2 py-0.5 rounded-md">ForceDecks Dual Plates</span>
              </div>
              <h4 className="font-black text-slate-800 text-sm mt-1 flex items-center gap-1.5">
                <Zap size={16} className="text-amber-500" />
                ForceDecks CMJ (MSS & Güç)
              </h4>
            </div>

            <div className="p-5 space-y-4 flex-1">
              {/* Baseline references */}
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 space-y-2">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Bireysel Bazal Değerler</span>
                <div className="grid grid-cols-3 gap-2 text-center text-[10px]">
                  <div>
                    <span className="text-slate-400 block">Bazal RSI</span>
                    <input 
                      type="number" 
                      step="0.01"
                      value={baseRsiMod} 
                      onChange={(e) => setBaseRsiMod(parseFloat(e.target.value) || 0.45)}
                      className="w-full text-center bg-white border border-slate-200 rounded p-1 font-bold font-mono mt-0.5"
                    />
                  </div>
                  <div>
                    <span className="text-slate-400 block">Bazal Güç</span>
                    <input 
                      type="number" 
                      step="0.1"
                      value={basePeakPower} 
                      onChange={(e) => setBasePeakPower(parseFloat(e.target.value) || 53)}
                      className="w-full text-center bg-white border border-slate-200 rounded p-1 font-bold font-mono mt-0.5"
                    />
                  </div>
                  <div>
                    <span className="text-slate-400 block">Bazal Asym</span>
                    <input 
                      type="number" 
                      step="0.1"
                      value={baseCmjAsym} 
                      onChange={(e) => setBaseCmjAsym(parseFloat(e.target.value) || 6)}
                      className="w-full text-center bg-white border border-slate-200 rounded p-1 font-bold font-mono mt-0.5"
                    />
                  </div>
                </div>
              </div>

              {/* Today's live inputs */}
              <div className="space-y-3">
                <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-wider block">Bugünkü Ölçülen Değerler</span>
                
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-600 block">Uçuş Süresi (ms)</label>
                    <input
                      type="number"
                      min="100"
                      max="1000"
                      value={flightTime}
                      onChange={(e) => setFlightTime(parseInt(e.target.value) || 0)}
                      className="w-full text-xs font-bold font-mono bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-center"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-600 block">Kasılma Süresi (ms)</label>
                    <input
                      type="number"
                      min="100"
                      max="2000"
                      value={contractionTime}
                      onChange={(e) => setContractionTime(parseInt(e.target.value) || 0)}
                      className="w-full text-xs font-bold font-mono bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-center"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 block">Peak Power (W/kg)</label>
                  <input
                    type="number"
                    step="0.1"
                    min="10"
                    max="100"
                    value={peakPower}
                    onChange={(e) => setPeakPower(parseFloat(e.target.value) || 0)}
                    className="w-full text-xs font-bold font-mono bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-center"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3 pt-1">
                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-500 block">Sol Fren İmp. (Ns)</label>
                    <input
                      type="number"
                      value={leftCmjImpulse}
                      onChange={(e) => setLeftCmjImpulse(parseInt(e.target.value) || 0)}
                      className="w-full text-xs font-semibold bg-slate-50 border border-slate-200 rounded-lg p-2 text-center"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-500 block">Sağ Fren İmp. (Ns)</label>
                    <input
                      type="number"
                      value={rightCmjImpulse}
                      onChange={(e) => setRightCmjImpulse(parseInt(e.target.value) || 0)}
                      className="w-full text-xs font-semibold bg-slate-50 border border-slate-200 rounded-lg p-2 text-center"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* LIVE CALCULATED RATIOS */}
            <div className="p-4 bg-slate-900 text-slate-100 border-t border-slate-800 space-y-3">
              <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block">OTOMATİK HESAPLANAN RATİOLAR</span>
              
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">RSI-Modified:</span>
                  <div className="flex items-center gap-1.5 font-mono">
                    <strong className="text-white text-sm">{calculatedRsiMod.toFixed(2)}</strong>
                    <span className={`text-[10px] font-bold px-1 rounded ${rsiDropPct > 7 ? "text-rose-400 bg-rose-500/15" : "text-emerald-400 bg-emerald-500/15"}`}>
                      {rsiDropPct > 0 ? `-${rsiDropPct}%` : `+${Math.abs(rsiDropPct)}%`}
                    </span>
                  </div>
                </div>

                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">Frenleme Asimetrisi:</span>
                  <div className="flex items-center gap-1.5 font-mono">
                    <strong className="text-white text-sm">{calculatedAsymFD}%</strong>
                    <span className={`text-[10px] font-bold px-1 rounded ${calculatedAsymFD > 15 ? "text-rose-400 bg-rose-500/15" : calculatedAsymFD > 10 ? "text-amber-400 bg-amber-500/15" : "text-emerald-400 bg-emerald-500/15"}`}>
                      {calculatedAsymFD <= 10 ? "İDEAL" : calculatedAsymFD <= 15 ? "SINIR" : "KRİTİK"}
                    </span>
                  </div>
                </div>

                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">Tepe Güç (W/kg):</span>
                  <div className="flex items-center gap-1.5 font-mono text-white text-sm">
                    <strong>{peakPower}</strong>
                    <span className="text-[10px] text-slate-400">({peakPowerDropPct > 0 ? `-${peakPowerDropPct}%` : `+${Math.abs(peakPowerDropPct)}%`})</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* STATION 2: FORCE_FRAME GROIN SQUEEZE */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xs flex flex-col justify-between overflow-hidden">
            <div className="p-5 border-b border-slate-100 bg-slate-50/50">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider">İSTASYON 2</span>
                <span className="bg-emerald-50 text-emerald-700 border border-emerald-100 text-[9px] font-mono font-bold px-2 py-0.5 rounded-md">ForceFrame Squeeze Bar</span>
              </div>
              <h4 className="font-black text-slate-800 text-sm mt-1 flex items-center gap-1.5">
                <Atom size={16} className="text-emerald-500" />
                ForceFrame Groin Squeeze (Kasık)
              </h4>
            </div>

            <div className="p-5 space-y-4 flex-1">
              {/* Baseline references */}
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 space-y-2">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Bireysel Bazal Değerler</span>
                <div className="grid grid-cols-2 gap-2 text-center text-[10px]">
                  <div>
                    <span className="text-slate-400 block">Bazal Sıkma Gücü (N)</span>
                    <input 
                      type="number" 
                      value={baseAddForce} 
                      onChange={(e) => setBaseAddForce(parseInt(e.target.value) || 490)}
                      className="w-full text-center bg-white border border-slate-200 rounded p-1 font-bold font-mono mt-0.5"
                    />
                  </div>
                  <div>
                    <span className="text-slate-400 block">Bazal Kasık Asym</span>
                    <input 
                      type="number" 
                      step="0.1"
                      value={baseGroinAsym} 
                      onChange={(e) => setBaseGroinAsym(parseFloat(e.target.value) || 5.5)}
                      className="w-full text-center bg-white border border-slate-200 rounded p-1 font-bold font-mono mt-0.5"
                    />
                  </div>
                </div>
              </div>

              {/* Today's live inputs */}
              <div className="space-y-3">
                <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-wider block">Bugünkü Ölçülen Değerler</span>
                
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-600 block">Sol Adduksiyon (N)</label>
                    <input
                      type="number"
                      value={leftAddForce}
                      onChange={(e) => setLeftAddForce(parseInt(e.target.value) || 0)}
                      className="w-full text-xs font-bold font-mono bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-center"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-600 block">Sağ Adduksiyon (N)</label>
                    <input
                      type="number"
                      value={rightAddForce}
                      onChange={(e) => setRightAddForce(parseInt(e.target.value) || 0)}
                      className="w-full text-xs font-bold font-mono bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-center"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 pt-1">
                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-500 block">Sol Abduksiyon (N)</label>
                    <input
                      type="number"
                      value={leftAbdForce}
                      onChange={(e) => setLeftAbdForce(parseInt(e.target.value) || 0)}
                      className="w-full text-xs font-semibold bg-slate-50 border border-slate-200 rounded-lg p-2 text-center"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-500 block">Sağ Abduksiyon (N)</label>
                    <input
                      type="number"
                      value={rightAbdForce}
                      onChange={(e) => setRightAbdForce(parseInt(e.target.value) || 0)}
                      className="w-full text-xs font-semibold bg-slate-50 border border-slate-200 rounded-lg p-2 text-center"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* LIVE CALCULATED RATIOS */}
            <div className="p-4 bg-slate-900 text-slate-100 border-t border-slate-800 space-y-3">
              <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block">OTOMATİK HESAPLANAN RATİOLAR</span>
              
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">Toplam Sıkma Kuvveti:</span>
                  <div className="flex items-center gap-1.5 font-mono">
                    <strong className="text-white text-sm">{calculatedAddForceTotal} N</strong>
                    <span className={`text-[10px] font-bold px-1 rounded ${groinForceDropPct > 10 ? "text-rose-400 bg-rose-500/15" : "text-emerald-400 bg-emerald-500/15"}`}>
                      {groinForceDropPct > 0 ? `-${groinForceDropPct}%` : `+${Math.abs(groinForceDropPct)}%`}
                    </span>
                  </div>
                </div>

                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">Kasık Sol/Sağ Asimetri:</span>
                  <div className="flex items-center gap-1.5 font-mono">
                    <strong className="text-white text-sm">{calculatedAsymFF}%</strong>
                    <span className={`text-[10px] font-bold px-1 rounded ${calculatedAsymFF > 15 ? "text-rose-400 bg-rose-500/15" : calculatedAsymFF > 10 ? "text-amber-400 bg-amber-500/15" : "text-emerald-400 bg-emerald-500/15"}`}>
                      {calculatedAsymFF <= 10 ? "İDEAL" : calculatedAsymFF <= 15 ? "SINIR" : "KRİTİK"}
                    </span>
                  </div>
                </div>

                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">Adduksiyon / Abduksiyon:</span>
                  <div className="flex items-center gap-1.5 font-mono text-white text-sm">
                    <strong>{calculatedAddAbdRatio}</strong>
                    <span className={`text-[10px] font-bold px-1 rounded ${calculatedAddAbdRatio >= 1.00 && calculatedAddAbdRatio <= 1.15 ? "text-emerald-400 bg-emerald-500/15" : "text-amber-400 bg-amber-500/15"}`}>
                      {calculatedAddAbdRatio >= 1.00 && calculatedAddAbdRatio <= 1.15 ? "DENGELİ" : "DENGESİZ"}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* STATION 3: NORDBORD */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xs flex flex-col justify-between overflow-hidden">
            <div className="p-5 border-b border-slate-100 bg-slate-50/50">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider">İSTASYON 3</span>
                <span className="bg-rose-50 text-rose-700 border border-rose-100 text-[9px] font-mono font-bold px-2 py-0.5 rounded-md">NordBord Hooks</span>
              </div>
              <h4 className="font-black text-slate-800 text-sm mt-1 flex items-center gap-1.5">
                <HeartPulse size={16} className="text-rose-500" />
                NordBord (Arka Zincir Toleransı)
              </h4>
            </div>

            <div className="p-5 space-y-4 flex-1">
              {/* Baseline references */}
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 space-y-2">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Bireysel Bazal Değerler</span>
                <div className="grid grid-cols-2 gap-2 text-center text-[10px]">
                  <div>
                    <span className="text-slate-400 block">Bazal Nordic (N)</span>
                    <input 
                      type="number" 
                      value={baseNbForce} 
                      onChange={(e) => setBaseNbForce(parseInt(e.target.value) || 380)}
                      className="w-full text-center bg-white border border-slate-200 rounded p-1 font-bold font-mono mt-0.5"
                    />
                  </div>
                  <div>
                    <span className="text-slate-400 block">Bazal Nordic Asym</span>
                    <input 
                      type="number" 
                      step="0.1"
                      value={baseNbAsym} 
                      onChange={(e) => setBaseNbAsym(parseFloat(e.target.value) || 6)}
                      className="w-full text-center bg-white border border-slate-200 rounded p-1 font-bold font-mono mt-0.5"
                    />
                  </div>
                </div>
              </div>

              {/* Today's live inputs */}
              <div className="space-y-3">
                <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-wider block">Bugünkü Ölçülen Değerler</span>
                
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-600 block">Sol Hamstring (N)</label>
                    <input
                      type="number"
                      value={leftNbForce}
                      onChange={(e) => setLeftNbForce(parseInt(e.target.value) || 0)}
                      className="w-full text-xs font-bold font-mono bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-center"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-600 block">Sağ Hamstring (N)</label>
                    <input
                      type="number"
                      value={rightNbForce}
                      onChange={(e) => setRightNbForce(parseInt(e.target.value) || 0)}
                      className="w-full text-xs font-bold font-mono bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-center"
                    />
                  </div>
                </div>

                <div className="p-3 bg-rose-50/50 rounded-xl border border-rose-100/40 text-[10px] text-rose-800 leading-relaxed mt-2">
                  ℹ️ <strong>Test Protokolü:</strong> DOMS (gecikmiş kas ağrısı) riskini sıfırlamak için antrenman öncesi aktivasyon sonunda <strong>sadece 1 veya 2 maksimal Nordic hamstring tekrarı</strong> yapılır.
                </div>
              </div>
            </div>

            {/* LIVE CALCULATED RATIOS */}
            <div className="p-4 bg-slate-900 text-slate-100 border-t border-slate-800 space-y-3">
              <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block">OTOMATİK HESAPLANAN RATİOLAR</span>
              
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">Toplam Hamstring Kuvveti:</span>
                  <div className="flex items-center gap-1.5 font-mono">
                    <strong className="text-white text-sm">{calculatedNbTotal} N</strong>
                    <span className={`text-[10px] font-bold px-1 rounded ${nbForceDropPct > 15 ? "text-rose-400 bg-rose-500/15" : "text-emerald-400 bg-emerald-500/15"}`}>
                      {nbForceDropPct > 0 ? `-${nbForceDropPct}%` : `+${Math.abs(nbForceDropPct)}%`}
                    </span>
                  </div>
                </div>

                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">Hamstring Sol/Sağ Asym:</span>
                  <div className="flex items-center gap-1.5 font-mono">
                    <strong className="text-white text-sm">{calculatedAsymNB}%</strong>
                    <span className={`text-[10px] font-bold px-1 rounded ${calculatedAsymNB > 15 ? "text-rose-400 bg-rose-500/15" : calculatedAsymNB > 10 ? "text-amber-400 bg-amber-500/15" : "text-emerald-400 bg-emerald-500/15"}`}>
                      {calculatedAsymNB <= 10 ? "İDEAL" : calculatedAsymNB <= 15 ? "SINIR" : "KRİTİK"}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* 4. CLINICAL ACTIONS BOARD */}
        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-xs space-y-4">
          <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
            <h3 className="text-sm font-black text-slate-800 flex items-center gap-2">
              <Gauge className="text-indigo-600" size={18} />
              ⚙️ Algoritma Eşik Kriterleri & Uygulama Kuralı Özeti
            </h3>
            <span className="text-[10px] font-mono text-slate-400">Geri Bildirim Motoru v2.0</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="border border-emerald-150 bg-emerald-50/20 p-4 rounded-xl space-y-2">
              <span className="text-emerald-800 font-extrabold flex items-center gap-1">
                <span className="h-2 w-2 bg-emerald-500 rounded-full shrink-0" />
                Yeşil Işık (Oyna ve Yükle)
              </span>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                Tüm asimetriler <strong>&lt; %10</strong> ve tüm tepe kuvvet / reaktif indeksler bazal durumun üzerinde veya eşit olmalıdır. İdmana %100 katılım verilir.
              </p>
            </div>

            <div className="border border-amber-150 bg-amber-50/20 p-4 rounded-xl space-y-2">
              <span className="text-amber-800 font-extrabold flex items-center gap-1">
                <span className="h-2 w-2 bg-amber-400 rounded-full shrink-0" />
                Sarı Işık (Dikkat - Modifiye Et)
              </span>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                RSI-Modified yorgunluk kaybı <strong>&gt; %7</strong> VEYA kasık sıkıştırma kuvveti <strong>&gt; %10</strong> düşüş gösteriyorsa tetiklenir. Toplam mesafe %15-20 kısıtlanır.
              </p>
            </div>

            <div className="border border-rose-150 bg-rose-50/20 p-4 rounded-xl space-y-2">
              <span className="text-rose-800 font-extrabold flex items-center gap-1">
                <span className="h-2 w-2 bg-rose-500 rounded-full shrink-0" />
                Kırmızı Işık (Tehlike / Yüksek Risk)
              </span>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                Herhangi bir bacak asimetrisi <strong>&gt; %15</strong> VEYA kasık / hamstring tepe kuvvet kaybı <strong>&gt; %15</strong> ise tetiklenir. Sahaya çıkış durdurulur, kliniğe alınır.
              </p>
            </div>
          </div>
        </div>

        {/* 5. SUBMIT ACTIONS */}
        <div className="flex items-center justify-end pt-2">
          <button
            type="submit"
            className="w-full md:w-auto md:px-10 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold py-4 rounded-xl transition shadow-sm flex items-center justify-center gap-2 text-sm cursor-pointer"
          >
            <Save size={18} />
            Ham Verileri İşle, Rasyoları Hesapla ve Profiline Kaydet
          </button>
        </div>
      </form>
    </div>
  );
}
