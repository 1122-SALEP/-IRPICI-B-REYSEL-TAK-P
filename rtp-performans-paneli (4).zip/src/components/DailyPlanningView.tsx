import React, { useState } from "react";
import { Player, DailyPlan } from "../types";
import { ClipboardList, Save, Trash2, Calendar, Target, Award, Dumbbell, Zap, HeartPulse, Flame, Activity } from "lucide-react";

interface DailyPlanningViewProps {
  selectedPlayer: Player;
  dailyPlans: DailyPlan[];
  onAddDailyPlan: (plan: Omit<DailyPlan, "id">) => void;
  onDeleteDailyPlan: (id: string) => void;
  selectedDate: string;
}

const PRESETS = [
  {
    name: "Linear Speed & Power (Lineer Hız & Güç)",
    type: "Saha İdmanı",
    warmup: "10 dk RAMP Isınma: Dinamik mobilizasyon, kalça açma ve hafif ısınma koşuları",
    coreActivation: "Anti-rotasyonel Paloff Press 3x10, Deadbug ve Glute Bridge varyasyonları ile lumbopelvik stabilizasyon",
    plyoSaq: "Merdiven koordinasyon drilleri, Hurdle Jump (Frenlemeli sıçrama) 3x4, 3x15m reaktif kısa çıkışlar",
    resistance: "Trapbar Deadlift 3x5 (%80 1RM - 3 sn yavaş eksantrik iniş), Bulgar Split Squat 3x6",
    energyProtocol: "Alaktasid Güç Gelişimi: 4x40m Maksimal Sprint (Tam dinlenme, seans arası tempo)",
    targetDistance: 3800,
    targetHsr: 350,
    targetRpe: 7
  },
  {
    name: "Eccentric Force & Load (Eksantrik Yükleme)",
    type: "Kombine (Saha + Gym)",
    warmup: "12 dk Fonksiyonel Isınma: Eklem mobilizasyonu, hamstring dinamik esnemeleri",
    coreActivation: "Plank 3x45 sn, Single leg glute bridge 3x12, Canavarlarla bant yana yürüyüş",
    plyoSaq: "Lateral Sıçramalar 3x6, Çeviklik Merdiveni Hızlı Ayak Adımları",
    resistance: "Nordic Hamstring 3x4, Tek Bacak Köprü Varyasyonları, Eksantrik Goblet Squat 3x8",
    energyProtocol: "Aerobik Laktat Eşiği Protokolü: 15 dk Sürekli Doğrusal Koşu (Düşük/Orta Yoğunluk)",
    targetDistance: 4500,
    targetHsr: 150,
    targetRpe: 6
  },
  {
    name: "Active Recovery & Rehab (Aktif Toparlanma)",
    type: "Rehab / Fizyoterapi",
    warmup: "15 dk Genel Mobilite: Derin nefes egzersizleri ve hafif yoga akışı",
    coreActivation: "Pelvik Tilts 3x15, Kuş-Köpek (Bird-Dog) 3x10, Kedi-Deve (Cat-Camel) mobilizasyonu",
    plyoSaq: "Yok (Sadece eklem koordinasyonu ve propriyosepsiyon denge tahtası çalışmaları)",
    resistance: "Klinik hamstring izometrik tutuşları (30 sn basılı tutma x 4 bacak başı)",
    energyProtocol: "Rejenerasyon Protokolü: 20 dk Sabit Tempo Bisiklet Ergosu (Laktat eşiği altı)",
    targetDistance: 600,
    targetHsr: 0,
    targetRpe: 2
  }
];

export default function DailyPlanningView({
  selectedPlayer,
  dailyPlans,
  onAddDailyPlan,
  onDeleteDailyPlan,
  selectedDate,
}: DailyPlanningViewProps) {
  const [idmanTipi, setIdmanTipi] = useState("Saha İdmanı");
  const [isinma, setIsinma] = useState("10 dk RAMP Isınma: Dinamik Esnemeler, Kalça Mobilizasyonu");
  const [coreAktivasyon, setCoreAktivasyon] = useState("Anti-rotasyonel Paloff Press 3x10, Deadbug 3x12, Glute Bridge 3x15");
  const [plyoSaq, setPlyoSaq] = useState("Hurdle Jump (Frenlemeli) 3x4, Merdiven Ayak Çalışmaları, Kısa Reaktif Çıkışlar");
  const [direnc, setDirenc] = useState("Trapbar Deadlift 3x5 (%80 1RM - Eksantrik Odak), Bulgar Split Squat 3x6");
  const [enerjiProtokol, setEnerjiProtokol] = useState("Aerobik Güç Gelişimi: 4x60m Progresif İlerleyen Koşular (Giderek Artan Hız)");
  
  const [hedefMesafe, setHedefMesafe] = useState(4500);
  const [hedefHsr, setHedefHsr] = useState(300);
  const [hedefRpe, setHedefRpe] = useState(6);
  
  const [successMsg, setSuccessMsg] = useState("");

  const handleApplyPreset = (preset: typeof PRESETS[0]) => {
    setIdmanTipi(preset.type);
    setIsinma(preset.warmup);
    setCoreAktivasyon(preset.coreActivation);
    setPlyoSaq(preset.plyoSaq);
    setDirenc(preset.resistance);
    setEnerjiProtokol(preset.energyProtocol);
    setHedefMesafe(preset.targetDistance);
    setHedefHsr(preset.targetHsr);
    setHedefRpe(preset.targetRpe);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddDailyPlan({
      playerId: selectedPlayer.id,
      date: selectedDate,
      type: idmanTipi,
      warmup: isinma,
      coreActivation: coreAktivasyon,
      plyoSaq: plyoSaq,
      resistance: direnc,
      energyProtocol: enerjiProtokol,
      targetDistance: hedefMesafe,
      targetHsr: hedefHsr,
      targetRpe: hedefRpe,
    });

    setSuccessMsg("5 Aşamalı Günlük idman planı başarıyla oluşturuldu ve yayınlandı!");
    setTimeout(() => setSuccessMsg(""), 4000);
  };

  const playerDailyPlans = dailyPlans.filter(p => p.playerId === selectedPlayer.id);

  return (
    <div className="space-y-6" id="daily-planning-view-root">
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm animate-fade-in">
        <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
          <ClipboardList className="text-emerald-600 h-6 w-6" />
          📝 Günlük İdman/Drill Planlama ve Programlama (5 Aşamalı Protokol)
        </h2>
        <p className="text-xs text-slate-500 mt-1">
          {selectedPlayer.name} için <strong>{selectedDate}</strong> tarihli antrenman planını modern atletik performans kriterlerine göre tasarlayın.
        </p>
      </div>

      {/* Preset Cards */}
      <div className="space-y-2">
        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Hızlı İdman Şablonları (Hazır Paketler)</span>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {PRESETS.map((preset, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleApplyPreset(preset)}
              className="bg-white p-3.5 rounded-xl border border-slate-100 shadow-xs hover:border-emerald-500 hover:bg-emerald-50/10 text-left transition group space-y-1.5 focus:outline-hidden cursor-pointer"
            >
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">
                  {preset.type}
                </span>
                <Award size={14} className="text-slate-300 group-hover:text-emerald-500 transition" />
              </div>
              <h4 className="text-xs font-bold text-slate-800">{preset.name}</h4>
              <p className="text-[10px] text-slate-500 line-clamp-1">Direnç: {preset.resistance}</p>
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Form Panel */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
          <form onSubmit={handleSubmit} className="space-y-5">
            {successMsg && (
              <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold p-4 rounded-xl animate-fade-in flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-emerald-500" />
                {successMsg}
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-slate-600 uppercase block mb-1">Seçilen Plan Tarihi</label>
                <div className="bg-slate-100 border border-slate-200 text-slate-800 text-sm rounded-xl px-3.5 py-2.5 font-bold font-mono">
                  {selectedDate}
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600 uppercase block mb-1">Antrenman Türü</label>
                <select
                  value={idmanTipi}
                  onChange={(e) => setIdmanTipi(e.target.value)}
                  className="w-full text-sm bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-slate-800 focus:outline-hidden focus:border-emerald-500 cursor-pointer"
                >
                  <option value="Saha İdmanı">Saha İdmanı</option>
                  <option value="Gym / Kuvvet Seansı">Gym / Kuvvet Seansı</option>
                  <option value="Kombine (Saha + Gym)">Kombine (Saha + Gym)</option>
                  <option value="Rehab / Fizyoterapi">Rehab / Fizyoterapi</option>
                </select>
              </div>
            </div>

            {/* 5-Step Training Sections */}
            <div className="space-y-4 pt-2 border-t border-slate-100">
              <span className="text-xs font-extrabold text-slate-400 uppercase tracking-widest block">Protokol Detayları</span>
              
              <div className="space-y-3.5">
                {/* Step 1: Isınma */}
                <div className="space-y-1 bg-slate-50/50 p-3 rounded-xl border border-slate-100">
                  <label className="text-xs font-bold text-indigo-700 block flex items-center gap-1.5">
                    <HeartPulse size={14} />
                    1-) Isınma & Mobilizasyon (RAMP Protokolü)
                  </label>
                  <textarea
                    rows={2}
                    value={isinma}
                    onChange={(e) => setIsinma(e.target.value)}
                    className="w-full text-sm bg-white border border-slate-200 rounded-lg px-3 py-2 text-slate-800 focus:outline-hidden focus:border-indigo-500"
                    required
                  />
                </div>

                {/* Step 2: Core-Aktivasyon */}
                <div className="space-y-1 bg-slate-50/50 p-3 rounded-xl border border-slate-100">
                  <label className="text-xs font-bold text-blue-700 block flex items-center gap-1.5">
                    <Activity size={14} />
                    2-) Core-Aktivasyon (Lumbopelvik Stabilite)
                  </label>
                  <textarea
                    rows={2}
                    value={coreAktivasyon}
                    onChange={(e) => setCoreAktivasyon(e.target.value)}
                    className="w-full text-sm bg-white border border-slate-200 rounded-lg px-3 py-2 text-slate-800 focus:outline-hidden focus:border-blue-500"
                    required
                  />
                </div>

                {/* Step 3: Pliometri ve Saq */}
                <div className="space-y-1 bg-slate-50/50 p-3 rounded-xl border border-slate-100">
                  <label className="text-xs font-bold text-amber-700 block flex items-center gap-1.5">
                    <Zap size={14} />
                    3-) Pliometri ve SAQ (Çeviklik & Hızlı Ayak)
                  </label>
                  <textarea
                    rows={2}
                    value={plyoSaq}
                    onChange={(e) => setPlyoSaq(e.target.value)}
                    className="w-full text-sm bg-white border border-slate-200 rounded-lg px-3 py-2 text-slate-800 focus:outline-hidden focus:border-amber-500"
                    required
                  />
                </div>

                {/* Step 4: Direnç */}
                <div className="space-y-1 bg-slate-50/50 p-3 rounded-xl border border-slate-100">
                  <label className="text-xs font-bold text-emerald-700 block flex items-center gap-1.5">
                    <Dumbbell size={14} />
                    4-) Direnç (Eksantrik ve İzometrik Kuvvet)
                  </label>
                  <textarea
                    rows={2}
                    value={direnc}
                    onChange={(e) => setDirenc(e.target.value)}
                    className="w-full text-sm bg-white border border-slate-200 rounded-lg px-3 py-2 text-slate-800 focus:outline-hidden focus:border-emerald-500"
                    required
                  />
                </div>

                {/* Step 5: Metabolik */}
                <div className="space-y-1 bg-slate-50/50 p-3 rounded-xl border border-slate-100">
                  <label className="text-xs font-bold text-rose-700 block flex items-center gap-1.5">
                    <Flame size={14} />
                    5-) Metabolik
                  </label>
                  <textarea
                    rows={2}
                    value={enerjiProtokol}
                    onChange={(e) => setEnerjiProtokol(e.target.value)}
                    className="w-full text-sm bg-white border border-slate-200 rounded-lg px-3 py-2 text-slate-800 focus:outline-hidden focus:border-rose-500"
                    required
                  />
                </div>
              </div>
            </div>

            {/* GPS Targets */}
            <div className="space-y-4 pt-4 border-t border-slate-100">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                <Target size={14} className="text-emerald-500" />
                Hedef Dış Yük Metrikleri (GPS Sınırları)
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 space-y-2">
                  <label className="text-xs font-bold text-slate-600 block">Hedef Toplam Mesafe (m)</label>
                  <input
                    type="number"
                    min="0"
                    max="15000"
                    step="100"
                    value={hedefMesafe}
                    onChange={(e) => setHedefMesafe(parseInt(e.target.value) || 0)}
                    className="w-full text-xs font-bold font-mono bg-white border border-slate-200 rounded-lg p-2.5 text-center"
                  />
                </div>

                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 space-y-2">
                  <label className="text-xs font-bold text-slate-600 block">Target HSR (m)</label>
                  <input
                    type="number"
                    min="0"
                    max="2000"
                    step="20"
                    value={hedefHsr}
                    onChange={(e) => setHedefHsr(parseInt(e.target.value) || 0)}
                    className="w-full text-xs font-bold font-mono bg-white border border-slate-200 rounded-lg p-2.5 text-center"
                  />
                </div>

                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 space-y-2">
                  <label className="text-xs font-bold text-slate-600 block">Öngörülen Seans RPE</label>
                  <input
                    type="number"
                    min="1"
                    max="10"
                    step="1"
                    value={hedefRpe}
                    onChange={(e) => setHedefRpe(parseInt(e.target.value) || 0)}
                    className="w-full text-xs font-bold font-mono bg-white border border-slate-200 rounded-lg p-2.5 text-center"
                  />
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 px-4 rounded-xl shadow-xs transition flex items-center justify-center gap-2 text-sm cursor-pointer"
            >
              <Save size={18} />
              5 Aşamalı Günlük Planı Yayınla
            </button>
          </form>
        </div>

        {/* Saved Daily Plans */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm space-y-4">
          <h3 className="font-bold text-slate-800 text-sm border-b border-slate-100 pb-3 flex items-center gap-2">
            <Calendar size={18} className="text-slate-500" />
            Yayınlanmış Planlar
          </h3>

          {playerDailyPlans.length > 0 ? (
            <div className="space-y-4 overflow-y-auto max-h-[700px] pr-1">
              {playerDailyPlans.map((plan) => (
                <div key={plan.id} className="p-4 bg-slate-50 border border-slate-100 rounded-xl space-y-3.5 relative group hover:border-emerald-300 transition-colors duration-200">
                  <button
                    onClick={() => onDeleteDailyPlan(plan.id)}
                    className="absolute right-2.5 top-2.5 p-1 text-slate-400 hover:text-rose-500 rounded-lg transition"
                    title="Planı Sil"
                  >
                    <Trash2 size={14} />
                  </button>

                  <div className="flex justify-between items-center border-b border-slate-200/60 pb-2">
                    <span className="text-[11px] bg-slate-800 text-white font-bold px-2 py-0.5 rounded font-mono">
                      {plan.date}
                    </span>
                    <span className="text-[10px] bg-emerald-50 text-emerald-700 font-extrabold px-1.5 py-0.5 rounded">
                      {plan.type}
                    </span>
                  </div>

                  {/* Elegant stepper for the 5-step program */}
                  <div className="space-y-3 text-xs">
                    {/* 1. Isınma */}
                    <div className="bg-white p-2 rounded border border-slate-200/50 space-y-0.5">
                      <span className="text-[10px] font-extrabold text-indigo-700 uppercase block">1-) Isınma</span>
                      <p className="text-slate-700 leading-normal font-medium">{plan.warmup}</p>
                    </div>

                    {/* 2. Core-Aktivasyon */}
                    <div className="bg-white p-2 rounded border border-slate-200/50 space-y-0.5">
                      <span className="text-[10px] font-extrabold text-blue-700 uppercase block">2-) Core-Aktivasyon</span>
                      <p className="text-slate-700 leading-normal font-medium">{plan.coreActivation || "Belirtilmemiş"}</p>
                    </div>

                    {/* 3. Pliometri ve Saq */}
                    <div className="bg-white p-2 rounded border border-slate-200/50 space-y-0.5">
                      <span className="text-[10px] font-extrabold text-amber-700 uppercase block">3-) Pliometri ve Saq</span>
                      <p className="text-slate-700 leading-normal font-medium">{plan.plyoSaq || "Belirtilmemiş"}</p>
                    </div>

                    {/* 4. Direnç */}
                    <div className="bg-white p-2 rounded border border-slate-200/50 space-y-0.5">
                      <span className="text-[10px] font-extrabold text-emerald-700 uppercase block">4-) Direnç</span>
                      <p className="text-slate-700 leading-normal font-medium">{plan.resistance || "Belirtilmemiş"}</p>
                    </div>

                    {/* 5. Metabolik */}
                    <div className="bg-white p-2 rounded border border-slate-200/50 space-y-0.5">
                      <span className="text-[10px] font-extrabold text-rose-700 uppercase block">5-) Metabolik</span>
                      <p className="text-slate-700 leading-normal font-medium">{plan.energyProtocol || "Belirtilmemiş"}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-1 pt-2.5 border-t border-slate-200 text-[10px] text-center text-slate-500 font-bold">
                    <div>
                      <span className="text-slate-400 font-medium block">Mesafe</span>
                      <p className="text-slate-800">{plan.targetDistance}m</p>
                    </div>
                    <div>
                      <span className="text-slate-400 font-medium block">HSR</span>
                      <p className="text-slate-800">{plan.targetHsr}m</p>
                    </div>
                    <div>
                      <span className="text-slate-400 font-medium block">Seans RPE</span>
                      <p className="text-slate-800">RPE {plan.targetRpe}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-10 text-slate-400 text-xs">
              Kayıtlı günlük plan bulunamadı.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
