import React, { useState } from "react";
import { Player, RealizedLog } from "../types";
import { Sparkles, Save, Trash2, Calendar, Smile, AlertCircle } from "lucide-react";

interface DailyRealizedViewProps {
  selectedPlayer: Player;
  realizedLogs: RealizedLog[];
  onAddRealizedLog: (log: Omit<RealizedLog, "id" | "createdAt">) => void;
  onDeleteRealizedLog: (id: string) => void;
  selectedDate: string;
}

export default function DailyRealizedView({
  selectedPlayer,
  realizedLogs,
  onAddRealizedLog,
  onDeleteRealizedLog,
  selectedDate,
}: DailyRealizedViewProps) {
  const [rtpAsama, setRtpAsama] = useState(selectedPlayer.rtpStage);
  const [gerceklesenMesafe, setGerceklesenMesafe] = useState(4200);
  const [gerceklesenHsr, setGerceklesenHsr] = useState(250);
  const [sRpe, setSRpe] = useState(5); // session_rpe (1-10)
  const [vasAgri, setVasAgri] = useState(0); // vas_pain_score (0-10)
  const [duration, setDuration] = useState(60); // minutes
  const [sleepScore, setSleepScore] = useState(4); // 1-5
  const [fatigueScore, setFatigueScore] = useState(4); // 1-5
  const [stressScore, setStressScore] = useState(4); // 1-5
  
  const [successMsg, setSuccessMsg] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const calculatedSRpeVal = sRpe * duration;
    const calculatedWellness = parseFloat(((sleepScore + fatigueScore + stressScore) / 3).toFixed(2));

    onAddRealizedLog({
      playerId: selectedPlayer.id,
      date: selectedDate,
      rtpStage: rtpAsama,
      actualDistance: gerceklesenMesafe,
      actualHsr: gerceklesenHsr,
      actualRpe: sRpe,
      vasPain: vasAgri,
      
      // Section 3 PDF metrics
      vas_pain_score: vasAgri,
      session_rpe: sRpe,
      daily_training_duration: duration,
      sRPE: calculatedSRpeVal,
      sleep_score: sleepScore,
      fatigue_score: fatigueScore,
      stress_score: stressScore,
      wellness_score: calculatedWellness
    });

    setSuccessMsg("Gerçekleşen dış yük ve iç yük başarıyla sisteme işlendi. Ana panelden planlanan hedeflerle karşılaştırabilirsiniz.");
    setTimeout(() => setSuccessMsg(""), 5000);
  };

  const playerLogs = realizedLogs.filter((l) => l.playerId === selectedPlayer.id);

  // Auto-calculated live values for preview
  const liveSRPE = sRpe * duration;
  const liveWellness = parseFloat(((sleepScore + fatigueScore + stressScore) / 3).toFixed(2));

  return (
    <div className="space-y-6" id="daily-realized-view-root">
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
        <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
          <Sparkles className="text-rose-500 h-6 w-6" />
          🏃‍♂️ Gerçekleşen Antrenman Yükü ve Sporcu Yanıtı (PDF Entegre)
        </h2>
        <p className="text-xs text-slate-500 mt-1">
          İdman veya klinik seans bittikten sonra dış yük (GPS) ve iç yük (seans RPE, süre, sabah wellness parametreleri) verilerini girin.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Form panel */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
          <form onSubmit={handleSubmit} className="space-y-5">
            {successMsg && (
              <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold p-4 rounded-xl animate-fade-in flex items-start gap-2">
                <span className="h-2 w-2 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                <span>{successMsg}</span>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-slate-600 uppercase block mb-1">Kayıt Tarihi</label>
                <div className="bg-slate-100 border border-slate-200 text-slate-800 text-sm rounded-xl px-3.5 py-2.5 font-bold font-mono">
                  {selectedDate}
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600 uppercase block mb-1">Mevcut RTP Aşaması</label>
                <select
                  value={rtpAsama}
                  onChange={(e) => setRtpAsama(e.target.value)}
                  className="w-full text-sm bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-slate-800 focus:outline-hidden focus:border-rose-500"
                >
                  <option value="Aşama 1: Klinik">Aşama 1: Klinik</option>
                  <option value="Aşama 2: Düz Koşu">Aşama 2: Düz Koşu</option>
                  <option value="Aşama 3: Agility/Yön Değiştirme">Aşama 3: Agility/Yön Değiştirme</option>
                  <option value="Aşama 4: Takımla Kontrollü">Aşama 4: Takımla Kontrollü</option>
                </select>
              </div>
            </div>

            {/* GPS measurements */}
            <div className="border-t border-slate-100 pt-4 space-y-4">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Gerçekleşen Dış Yük Değerleri (GPS Verileri)</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 space-y-2">
                  <label className="text-xs font-bold text-slate-600 block">Gerçekleşen Toplam Mesafe (m)</label>
                  <input
                    type="number"
                    min="0"
                    max="15000"
                    step="50"
                    value={gerceklesenMesafe}
                    onChange={(e) => setGerceklesenMesafe(parseInt(e.target.value) || 0)}
                    className="w-full text-xs font-bold font-mono bg-white border border-slate-200 rounded-lg p-2.5 text-center"
                  />
                </div>

                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 space-y-2">
                  <label className="text-xs font-bold text-slate-600 block">Gerçekleşen HSR (m)</label>
                  <input
                    type="number"
                    min="0"
                    max="3000"
                    step="10"
                    value={gerceklesenHsr}
                    onChange={(e) => setGerceklesenHsr(parseInt(e.target.value) || 0)}
                    className="w-full text-xs font-bold font-mono bg-white border border-slate-200 rounded-lg p-2.5 text-center"
                  />
                </div>
              </div>
            </div>

            {/* Subjective metrics & Internal load (Section 3 of PDF) */}
            <div className="border-t border-slate-100 pt-4 space-y-4">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Sporcu İç Yük, Antrenman Süresi ve Ağrı Yanıtı</h3>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Duration */}
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 space-y-2">
                  <label className="text-xs font-bold text-slate-600 block">Seans Süresi (dk)</label>
                  <input
                    type="number"
                    min="10"
                    max="180"
                    step="5"
                    value={duration}
                    onChange={(e) => setDuration(parseInt(e.target.value) || 0)}
                    className="w-full text-xs font-bold font-mono bg-white border border-slate-200 rounded-lg p-2.5 text-center"
                  />
                </div>

                {/* Session RPE */}
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 space-y-2">
                  <label className="text-xs font-bold text-slate-600 block">Seans RPE (1-10 Zorluk)</label>
                  <input
                    type="number"
                    min="1"
                    max="10"
                    step="1"
                    value={sRpe}
                    onChange={(e) => setSRpe(parseInt(e.target.value) || 0)}
                    className="w-full text-xs font-bold font-mono bg-white border border-slate-200 rounded-lg p-2.5 text-center"
                  />
                </div>

                {/* VAS Pain */}
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 space-y-2">
                  <label className="text-xs font-bold text-slate-600 block">Ağrı Skoru (VAS 0-10)</label>
                  <input
                    type="number"
                    min="0"
                    max="10"
                    step="1"
                    value={vasAgri}
                    onChange={(e) => setVasAgri(parseInt(e.target.value) || 0)}
                    className="w-full text-xs font-bold font-mono bg-white border border-slate-200 rounded-lg p-2.5 text-center"
                  />
                </div>
              </div>

              {/* Dynamic sRPE calculation display */}
              <div className="bg-indigo-50 border border-indigo-100 p-3.5 rounded-xl flex justify-between items-center text-xs">
                <div>
                  <span className="font-semibold text-slate-500">Hesaplanan İç Yük İndeksi:</span>
                  <span className="text-[10px] text-indigo-700 font-bold block">(RPE {sRpe} x {duration} dk)</span>
                </div>
                <strong className="text-lg font-mono font-black text-indigo-700">sRPE: {liveSRPE}</strong>
              </div>
            </div>

            {/* Morning Wellness Scores (Section 3 of PDF) */}
            <div className="border-t border-slate-100 pt-4 space-y-4">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Sabah Wellness / Rejenerasyon Parametreleri (1-5)</h3>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Sleep */}
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 space-y-2">
                  <label className="text-xs font-bold text-slate-600 block">Uyku Kalitesi (1-5)</label>
                  <input
                    type="number"
                    min="1"
                    max="5"
                    step="1"
                    value={sleepScore}
                    onChange={(e) => setSleepScore(parseInt(e.target.value) || 0)}
                    className="w-full text-xs font-bold font-mono bg-white border border-slate-200 rounded-lg p-2.5 text-center"
                  />
                </div>

                {/* Fatigue */}
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 space-y-2">
                  <label className="text-xs font-bold text-slate-600 block">Yorgunluk Seviyesi (1-5)</label>
                  <input
                    type="number"
                    min="1"
                    max="5"
                    step="1"
                    value={fatigueScore}
                    onChange={(e) => setFatigueScore(parseInt(e.target.value) || 0)}
                    className="w-full text-xs font-bold font-mono bg-white border border-slate-200 rounded-lg p-2.5 text-center"
                  />
                </div>

                {/* Stress */}
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 space-y-2">
                  <label className="text-xs font-bold text-slate-600 block">Stres Durumu (1-5)</label>
                  <input
                    type="number"
                    min="1"
                    max="5"
                    step="1"
                    value={stressScore}
                    onChange={(e) => setStressScore(parseInt(e.target.value) || 0)}
                    className="w-full text-xs font-bold font-mono bg-white border border-slate-200 rounded-lg p-2.5 text-center"
                  />
                </div>
              </div>

              {/* Dynamic Wellness average score display */}
              <div className="bg-emerald-50 border border-emerald-100 p-3.5 rounded-xl flex justify-between items-center text-xs">
                <div>
                  <span className="font-semibold text-slate-500">Ortalama Wellness Skoru:</span>
                  <span className="text-[10px] text-emerald-700 font-bold block">(Sleep + Fatigue + Stress) / 3</span>
                </div>
                <strong className="text-lg font-mono font-black text-emerald-700">Wellness: {liveWellness} / 5.0</strong>
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-rose-500 hover:bg-rose-600 text-white font-bold py-3 px-4 rounded-xl shadow-xs transition flex items-center justify-center gap-2 text-sm cursor-pointer"
            >
              <Save size={18} />
              Gerçekleşen Veriyi Kaydet
            </button>
          </form>
        </div>

        {/* History / Logs list */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm space-y-4">
          <h3 className="font-bold text-slate-800 text-sm border-b border-slate-100 pb-3 flex items-center gap-2">
            <Calendar size={18} className="text-slate-500" />
            Geçmiş Gerçekleşen Kayıtlar
          </h3>

          {playerLogs.length > 0 ? (
            <div className="space-y-3 overflow-y-auto max-h-[750px] pr-1">
              {playerLogs.map((log) => (
                <div key={log.id} className="p-3.5 bg-slate-50 border border-slate-100 rounded-xl space-y-2.5 relative group">
                  <button
                    onClick={() => onDeleteRealizedLog(log.id)}
                    className="absolute right-2 top-2 p-1 text-slate-400 hover:text-rose-500 rounded-lg transition cursor-pointer"
                    title="Kaydı Sil"
                  >
                    <Trash2 size={13} />
                  </button>

                  <div className="flex justify-between items-center text-xs">
                    <span className="font-bold text-slate-800 font-mono">{log.date}</span>
                    <span className="text-[9px] bg-slate-200 text-slate-700 font-bold px-1.5 py-0.5 rounded">
                      {log.rtpStage}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[10px] bg-white p-2 rounded border border-slate-100">
                    <div>
                      <span className="text-slate-400">Gerçekleşen Mesafe</span>
                      <p className="font-bold text-slate-800 mt-0.5">{log.actualDistance} m</p>
                    </div>
                    <div>
                      <span className="text-slate-400">Gerçekleşen HSR</span>
                      <p className="font-bold text-slate-800 mt-0.5">{log.actualHsr} m</p>
                    </div>
                    <div>
                      <span className="text-slate-400">Süre & RPE</span>
                      <p className="font-bold text-slate-800 mt-0.5">{log.daily_training_duration ?? 60} dk (RPE {log.actualRpe})</p>
                    </div>
                    <div>
                      <span className="text-slate-400">Ağrı Skoru</span>
                      <p className={`font-bold mt-0.5 ${log.vasPain >= 3 ? "text-rose-600" : "text-slate-800"}`}>
                        VAS {log.vasPain} / 10
                      </p>
                    </div>
                  </div>

                  {/* Section 3 internal load / wellness details inside history card */}
                  <div className="border-t border-slate-150 pt-2 grid grid-cols-2 gap-1.5 text-[9px] text-slate-500">
                    <div className="bg-indigo-50/50 p-1.5 rounded border border-indigo-100/50">
                      <span>İç Yük (sRPE):</span>
                      <strong className="text-indigo-700 block font-mono text-xs">{log.sRPE ?? (log.actualRpe * (log.daily_training_duration ?? 60))}</strong>
                    </div>
                    <div className="bg-emerald-50/50 p-1.5 rounded border border-emerald-100/50">
                      <span>Wellness Skoru:</span>
                      <strong className="text-emerald-700 block font-mono text-xs">{log.wellness_score ?? "4.33"} / 5.0</strong>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-10 text-slate-400 text-xs">
              Bu oyuncu için henüz gerçekleşen idman kaydı bulunamadı.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
