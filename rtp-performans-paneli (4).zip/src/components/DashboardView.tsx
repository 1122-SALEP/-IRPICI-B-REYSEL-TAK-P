import React, { useState, useEffect } from "react";
import { Player, WeeklyPlan, DailyPlan, RealizedLog } from "../types";
import { AlertTriangle, ShieldCheck, HelpCircle, Activity, ChevronRight, TrendingUp, Calendar, Clock, Sparkles } from "lucide-react";

interface DashboardViewProps {
  selectedPlayer: Player;
  weeklyPlans: WeeklyPlan[];
  dailyPlans: DailyPlan[];
  realizedLogs: RealizedLog[];
  onUpdatePlayerMetrics: (playerId: string, metrics: Partial<Player>) => void;
}

export function durumHesapla(
  vas: number,
  asymFD: number,
  asymNB: number,
  asymFF: number,
  hq: number,
  nordbordDrop: number,
  rsiDrop: boolean
) {
  const reasons: string[] = [];

  // Check RED conditions (Alarm / Kliniğe Dönüş):
  // 1. Any device limb asymmetry > 15.0%
  const hasRedAsym = asymFD > 15 || asymNB > 15 || asymFF > 15;
  if (asymFD > 15) reasons.push("ForceDecks CMJ Frenleme Asimetrisi > %15.0 kritik eşiğinde.");
  if (asymNB > 15) reasons.push("NordBord Nordic Hamstring Asimetrisi > %15.0 kritik eşiğinde.");
  if (asymFF > 15) reasons.push("ForceFrame Groin Squeeze Asimetrisi > %15.0 kritik eşiğinde.");

  // 2. Absolute force drop >= 15% compared to baseline/previous
  if (nordbordDrop >= 15) {
    reasons.push(`NordBord Mutlak Kuvvet Kaybı %${nordbordDrop} seviyesinde (Kritik düşüş limit eşiği >= %15.0).`);
  }

  // 3. vas_pain_score (VAS Pain) >= 3
  if (vas >= 3) {
    reasons.push(`Net Antrenman Ağrısı Tetiklenmesi (VAS: ${vas} / 10 >= 3).`);
  }

  // 4. Izokinetik H:Q ratio < 0.55
  if (hq < 0.55) {
    reasons.push(`Kritik İzokinetik Hamstring/Quadriceps Oranı (H:Q Oranı: ${hq} < 0.55).`);
  }

  const isRed = hasRedAsym || nordbordDrop >= 15 || vas >= 3 || hq < 0.55;

  if (isRed) {
    return {
      status: "🔴 KIRMIZI (Alarm / Kliniğe Dönüş)",
      message: "KRİTİK ALARM: Sahaya çıkışı durdurun, antrenman yükünü %50 azaltarak sporcuyu klinik rehabilitasyona yönlendirin.",
      variant: "danger" as const,
      color: "bg-rose-50 border-rose-200 text-rose-800",
      badgeColor: "bg-rose-500 text-white",
      reasons
    };
  }

  // Check GREEN conditions (Süreç Normal / Yükleme Serbest):
  // 1. All device limb asymmetries < 10.0%
  const isGreenAsym = asymFD < 10 && asymNB < 10 && asymFF < 10;
  // 2. Isokinetic H:Q Ratio > 0.60 AND vas_pain_score == 0
  const isGreenHq = hq > 0.60;
  const isGreenPain = vas === 0;
  const isGreenDrop = nordbordDrop < 10;

  if (isGreenAsym && isGreenHq && isGreenPain && !rsiDrop && isGreenDrop) {
    reasons.push("Tüm bacak asimetrileri koruyucu ve ideal aralıkta (< %10.0).");
    reasons.push("İzokinetik H:Q dengesi tam koruma seviyesinde (> 0.60).");
    reasons.push("Sporcuda hiçbir idman ağrısı bulunmuyor (VAS: 0).");
    reasons.push("Doku toleransı tam ve reaktif kuvvet kaybı bulunmuyor.");

    return {
      status: "🟢 YEŞİL (Süreç Normal / Yükleme Serbest)",
      message: "Sahaya çıkış ve yükleme onaylandı. Haftalık HSR ve Sprint hacmini %15 artırabilirsiniz.",
      variant: "success" as const,
      color: "bg-emerald-50 border-emerald-200 text-emerald-800",
      badgeColor: "bg-emerald-500 text-white",
      reasons
    };
  }

  // Otherwise Yellow (Kontrollü Devam / Sabitleme):
  if (asymFD >= 10 && asymFD <= 15) reasons.push("ForceDecks Frenleme Asimetrisi kontrollü bölgede (%10.0 - %15.0).");
  if (asymNB >= 10 && asymNB <= 15) reasons.push("NordBord Hamstring Asimetrisi kontrollü bölgede (%10.0 - %15.0).");
  if (asymFF >= 10 && asymFF <= 15) reasons.push("ForceFrame Groin Squeeze Asimetrisi kontrollü bölgede (%10.0 - %15.0).");
  if (rsiDrop) reasons.push("Reaktif Güç İndeksinde (RSI Modified) son teste kıyasla %10'dan fazla yorgunluk/düşüş var.");
  if (vas === 1 || vas === 2) reasons.push(`İdmana engel olmayan hafif sızı veya hassasiyet var (VAS: ${vas}).`);
  if (nordbordDrop >= 10 && nordbordDrop < 15) reasons.push(`Mutlak hamstring doku toleransı hafif yorgun (%${nordbordDrop} düşüş).`);

  if (reasons.length === 0) {
    reasons.push("Bazı parametreler hafif sınırda veya yeşil-sarı sınır geçiş bölgesinde.");
  }

  return {
    status: "🟡 SARI (Kontrollü Devam / Sabitleme)",
    message: "Frenleme ve adaptasyon yavaşlıyor. Mevcut RTP aşamasında kalın, sahadaki yön değiştirme hacmini sabitleyiniz.",
    variant: "warning" as const,
    color: "bg-amber-50 border-amber-200 text-amber-800",
    badgeColor: "bg-amber-500 text-slate-900",
    reasons
  };
}

export default function DashboardView({
  selectedPlayer,
  weeklyPlans,
  dailyPlans,
  realizedLogs,
  onUpdatePlayerMetrics,
}: DashboardViewProps) {
  // Local state for instant preview adjustments
  const [vas, setVas] = useState(selectedPlayer.vasPain);
  const [asymFD, setAsymFD] = useState(selectedPlayer.ecc_decel_impulse_asym ?? selectedPlayer.eccentricBrakingAsymmetry);
  const [asymNB, setAsymNB] = useState(selectedPlayer.nordbord_peak_force_asym ?? selectedPlayer.hamstringAsymmetry);
  const [asymFF, setAsymFF] = useState(selectedPlayer.groin_peak_force_asym ?? 5.0);
  const [hq, setHq] = useState(selectedPlayer.hq_ratio_60 ?? selectedPlayer.hqRatio);
  const [nordbordDrop, setNordbordDrop] = useState(selectedPlayer.nordbordDrop);
  const [rsiDrop, setRsiDrop] = useState(false);

  // Sync with selected player when selection changes
  useEffect(() => {
    setVas(selectedPlayer.vasPain);
    setAsymFD(selectedPlayer.ecc_decel_impulse_asym ?? selectedPlayer.eccentricBrakingAsymmetry);
    setAsymNB(selectedPlayer.nordbord_peak_force_asym ?? selectedPlayer.hamstringAsymmetry);
    setAsymFF(selectedPlayer.groin_peak_force_asym ?? 5.0);
    setHq(selectedPlayer.hq_ratio_60 ?? selectedPlayer.hqRatio);
    setNordbordDrop(selectedPlayer.nordbordDrop);
    setRsiDrop(false);
  }, [selectedPlayer]);

  const handleMetricChange = (field: string, val: any) => {
    if (field === "vas") {
      const v = parseInt(val);
      setVas(v);
      onUpdatePlayerMetrics(selectedPlayer.id, { vasPain: v });
    } else if (field === "asymFD") {
      const v = parseFloat(parseFloat(val).toFixed(1));
      setAsymFD(v);
      onUpdatePlayerMetrics(selectedPlayer.id, { asymmetry: v, eccentricBrakingAsymmetry: v, ecc_decel_impulse_asym: v });
    } else if (field === "asymNB") {
      const v = parseFloat(parseFloat(val).toFixed(1));
      setAsymNB(v);
      onUpdatePlayerMetrics(selectedPlayer.id, { hamstringAsymmetry: v, nordbord_peak_force_asym: v });
    } else if (field === "asymFF") {
      const v = parseFloat(parseFloat(val).toFixed(1));
      setAsymFF(v);
      onUpdatePlayerMetrics(selectedPlayer.id, { groin_peak_force_asym: v });
    } else if (field === "hq") {
      const v = parseFloat(parseFloat(val).toFixed(2));
      setHq(v);
      onUpdatePlayerMetrics(selectedPlayer.id, { hqRatio: v, hq_ratio_60: v });
    } else if (field === "nordbordDrop") {
      const v = parseFloat(parseFloat(val).toFixed(1));
      setNordbordDrop(v);
      onUpdatePlayerMetrics(selectedPlayer.id, { nordbordDrop: v });
    }
  };

  const decision = durumHesapla(vas, asymFD, asymNB, asymFF, hq, nordbordDrop, rsiDrop);

  // Filter player-specific lists
  const playerWeeklyPlans = weeklyPlans.filter(p => p.playerId === selectedPlayer.id);
  const playerDailyPlans = dailyPlans.filter(p => p.playerId === selectedPlayer.id);
  const playerLogs = realizedLogs.filter(p => p.playerId === selectedPlayer.id);

  return (
    <div className="space-y-6" id="dashboard-view-root">
      {/* Overview Info Card */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white p-6 rounded-2xl shadow-sm relative overflow-hidden" id="dashboard-hero-card">
        <div className="absolute right-0 top-0 opacity-10 translate-x-6 -translate-y-6">
          <Activity size={240} />
        </div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-emerald-400 bg-emerald-400/10 px-3 py-1 rounded-full border border-emerald-400/20 inline-block mb-2">
              RTP Canlı Sistem
            </span>
            <h2 className="text-2xl font-bold tracking-tight">{selectedPlayer.name}</h2>
            <p className="text-slate-300 text-sm mt-1">
              Aktif Klinik Durum ve Karar Destek Paneli (PDF Entegre)
            </p>
          </div>
          <div className="bg-white/10 backdrop-blur-md px-4 py-3 rounded-xl border border-white/10 text-right">
            <span className="text-xs text-slate-300 block">Güncel Aşama</span>
            <span className="font-semibold text-lg text-emerald-300">{selectedPlayer.rtpStage}</span>
          </div>
        </div>
      </div>

      {/* Traffic Light Algorithm Section */}
      <div className="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm space-y-6" id="traffic-light-section">
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div>
            <h3 className="font-bold text-slate-800 text-lg flex items-center gap-2">
              <span className="flex h-3 w-3 rounded-full bg-emerald-500 animate-ping" />
              🚦 Klinik Algoritma Kararı (Trafik Lambası)
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              VAS, ForceDecks, NordBord ve ForceFrame asimetri & düşüş oranlarına göre entegre şema
            </p>
          </div>
        </div>

        {/* Dynamic Sliders/Inputs for quick metric testing */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Section 1: Semptom ve Klinik */}
          <div className="bg-slate-50/70 p-4 rounded-xl border border-slate-100 space-y-4">
            <div className="border-b border-slate-200/60 pb-2">
              <span className="text-xs font-extrabold text-indigo-700 tracking-wider uppercase block">1. Semptom Takibi</span>
            </div>
            
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <label className="text-xs font-semibold text-slate-600 block">VAS Ağrı Skoru (0-10)</label>
                <span className={`text-xs font-bold px-2 py-0.5 rounded ${vas >= 3 ? "text-rose-600 bg-rose-100" : vas >= 1 ? "text-amber-600 bg-amber-100" : "text-emerald-600 bg-emerald-100"}`}>
                  VAS: {vas}
                </span>
              </div>
              <input
                type="number"
                min="0"
                max="10"
                step="1"
                value={vas}
                onChange={(e) => handleMetricChange("vas", e.target.value)}
                className="w-full text-xs font-bold font-mono bg-white border border-slate-200 rounded-lg p-2.5 text-center"
              />
            </div>
          </div>

          {/* Section 2: Cihaz Bazlı Bacak Asimetrileri */}
          <div className="bg-slate-50/70 p-4 rounded-xl border border-slate-100 space-y-4">
            <div className="border-b border-slate-200/60 pb-2">
              <span className="text-xs font-extrabold text-indigo-700 tracking-wider uppercase block">2. Cihaz Asimetrileri</span>
            </div>

            {/* ForceDecks CMJ Asymmetry */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-[11px] font-semibold text-slate-600 block">ForceDecks CMJ Frenleme (%)</label>
                <span className={`text-xs font-bold px-1.5 py-0.5 rounded ${asymFD >= 15 ? "text-rose-600 bg-rose-100" : asymFD >= 10 ? "text-amber-600 bg-amber-100" : "text-emerald-600 bg-emerald-100"}`}>
                  %{asymFD}
                </span>
              </div>
              <input
                type="number"
                min="0"
                max="25"
                step="0.5"
                value={asymFD}
                onChange={(e) => handleMetricChange("asymFD", e.target.value)}
                className="w-full text-xs font-bold font-mono bg-white border border-slate-200 rounded-lg p-2.5 text-center"
              />
            </div>

            {/* NordBord Asymmetry */}
            <div className="space-y-2 border-t border-slate-100 pt-2">
              <div className="flex justify-between items-center">
                <label className="text-[11px] font-semibold text-slate-600 block">NordBord Hamstring (%)</label>
                <span className={`text-xs font-bold px-1.5 py-0.5 rounded ${asymNB >= 15 ? "text-rose-600 bg-rose-100" : asymNB >= 10 ? "text-amber-600 bg-amber-100" : "text-emerald-600 bg-emerald-100"}`}>
                  %{asymNB}
                </span>
              </div>
              <input
                type="number"
                min="0"
                max="25"
                step="0.5"
                value={asymNB}
                onChange={(e) => handleMetricChange("asymNB", e.target.value)}
                className="w-full text-xs font-bold font-mono bg-white border border-slate-200 rounded-lg p-2.5 text-center"
              />
            </div>

            {/* ForceFrame Asymmetry */}
            <div className="space-y-2 border-t border-slate-100 pt-2">
              <div className="flex justify-between items-center">
                <label className="text-[11px] font-semibold text-slate-600 block">ForceFrame Groin Squeeze (%)</label>
                <span className={`text-xs font-bold px-1.5 py-0.5 rounded ${asymFF >= 15 ? "text-rose-600 bg-rose-100" : asymFF >= 10 ? "text-amber-600 bg-amber-100" : "text-emerald-600 bg-emerald-100"}`}>
                  %{asymFF}
                </span>
              </div>
              <input
                type="number"
                min="0"
                max="25"
                step="0.5"
                value={asymFF}
                onChange={(e) => handleMetricChange("asymFF", e.target.value)}
                className="w-full text-xs font-bold font-mono bg-white border border-slate-200 rounded-lg p-2.5 text-center"
              />
            </div>
          </div>

          {/* Section 3: Kuvvet, Güç ve Yorgunluk */}
          <div className="bg-slate-50/70 p-4 rounded-xl border border-slate-100 space-y-4">
            <div className="border-b border-slate-200/60 pb-2">
              <span className="text-xs font-extrabold text-indigo-700 tracking-wider uppercase block">3. Tolerans & Güç Takibi</span>
            </div>

            {/* Isokinetic HQ ratio */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-[11px] font-semibold text-slate-600 block">İzokinetik H:Q Oranı (60°/s)</label>
                <span className={`text-xs font-bold px-1.5 py-0.5 rounded ${hq >= 0.60 ? "text-emerald-600 bg-emerald-100" : hq >= 0.55 ? "text-amber-600 bg-amber-100" : "text-rose-600 bg-rose-100"}`}>
                  {hq}
                </span>
              </div>
              <input
                type="number"
                min="0.35"
                max="1.00"
                step="0.01"
                value={hq}
                onChange={(e) => handleMetricChange("hq", e.target.value)}
                className="w-full text-xs font-bold font-mono bg-white border border-slate-200 rounded-lg p-2.5 text-center"
              />
            </div>

            {/* NordBord Force Drop */}
            <div className="space-y-2 border-t border-slate-100 pt-2">
              <div className="flex justify-between items-center">
                <label className="text-[11px] font-semibold text-slate-600 block">NordBord Kuvvet Düşüşü (%)</label>
                <span className={`text-xs font-bold px-1.5 py-0.5 rounded ${nordbordDrop >= 15 ? "text-rose-600 bg-rose-100" : nordbordDrop >= 10 ? "text-amber-600 bg-amber-100" : "text-emerald-600 bg-emerald-100"}`}>
                  %{nordbordDrop}
                </span>
              </div>
              <input
                type="number"
                min="0"
                max="30"
                step="0.5"
                value={nordbordDrop}
                onChange={(e) => handleMetricChange("nordbordDrop", e.target.value)}
                className="w-full text-xs font-bold font-mono bg-white border border-slate-200 rounded-lg p-2.5 text-center"
              />
            </div>

            {/* RSI Modified Drop (Reactive Fatigue) Toggle */}
            <div className="border-t border-slate-100 pt-3 flex items-center justify-between">
              <span className="text-[11px] font-semibold text-slate-600">RSI Modified'da &gt;%10 Düşüş (Yorgunluk)</span>
              <input
                type="checkbox"
                checked={rsiDrop}
                onChange={(e) => setRsiDrop(e.target.checked)}
                className="h-4 w-4 text-indigo-600 border-slate-300 rounded cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Traffic Light Algorithm Output Box */}
        <div className={`border p-5 rounded-xl transition-all duration-300 ${decision.color}`} id="decision-output-box">
          <div className="flex items-start gap-4">
            <div className="mt-1">
              {decision.variant === "danger" && <AlertTriangle className="text-rose-600 h-6 w-6 shrink-0 animate-pulse" />}
              {decision.variant === "warning" && <AlertTriangle className="text-amber-600 h-6 w-6 shrink-0" />}
              {decision.variant === "success" && <ShieldCheck className="text-emerald-600 h-6 w-6 shrink-0 animate-bounce" />}
            </div>
            
            <div className="space-y-3 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className={`text-xs uppercase font-extrabold px-3 py-1 rounded-full ${decision.badgeColor} shadow-2xs`}>
                  {decision.status}
                </span>
                <span className="font-bold text-sm text-slate-800">Sistem Algoritmik Kararı</span>
              </div>
              <p className="text-sm font-bold leading-relaxed">
                {decision.message}
              </p>
              
              {/* List of reasons */}
              <div className="pt-2 border-t border-slate-200/40 space-y-1">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Karar Verme Gerekçeleri:</span>
                <ul className="list-disc list-inside text-xs space-y-1 font-medium text-slate-700">
                  {decision.reasons.map((r, i) => (
                    <li key={i}>{r}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Planned vs Realized Visual Comparison */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6" id="dashboard-lower-grid">
        {/* Weekly & Daily Plans */}
        <div className="space-y-6">
          {/* Weekly Microcycle Target */}
          <div className="bg-white rounded-2xl border border-slate-100 p-5 shadow-sm space-y-4">
            <h4 className="font-bold text-slate-800 flex items-center gap-2 text-sm border-b border-slate-100 pb-3">
              <Calendar size={18} className="text-indigo-500" />
              🗓️ Aktif Haftalık Mikroçevrim Hedefleri
            </h4>
            {playerWeeklyPlans.length > 0 ? (
              playerWeeklyPlans.map((wp) => (
                <div key={wp.id} className="space-y-3 bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="text-xs text-slate-500 font-medium block">Hafta Tanımı</span>
                      <span className="font-bold text-sm text-slate-800">{wp.weekNo}</span>
                    </div>
                    <span className="text-xs bg-indigo-50 text-indigo-600 font-bold px-2 py-1 rounded">
                      {wp.focus}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs mt-2">
                    <div className="bg-white p-2 rounded border border-slate-100">
                      <span className="text-slate-400 block font-semibold text-[10px]">Pzt</span>
                      <span className="text-slate-700 truncate block">{wp.mon || "Dinlenme"}</span>
                    </div>
                    <div className="bg-white p-2 rounded border border-slate-100">
                      <span className="text-slate-400 block font-semibold text-[10px]">Sal</span>
                      <span className="text-slate-700 truncate block">{wp.tue || "Dinlenme"}</span>
                    </div>
                    <div className="bg-white p-2 rounded border border-slate-100">
                      <span className="text-slate-400 block font-semibold text-[10px]">Çar</span>
                      <span className="text-slate-700 truncate block">{wp.wed || "Dinlenme"}</span>
                    </div>
                    <div className="bg-white p-2 rounded border border-slate-100">
                      <span className="text-slate-400 block font-semibold text-[10px]">Per</span>
                      <span className="text-slate-700 truncate block">{wp.thu || "Dinlenme"}</span>
                    </div>
                    <div className="bg-white p-2 rounded border border-slate-100">
                      <span className="text-slate-400 block font-semibold text-[10px]">Cum</span>
                      <span className="text-slate-700 truncate block">{wp.fri || "Dinlenme"}</span>
                    </div>
                    <div className="bg-white p-2 rounded border border-slate-100">
                      <span className="text-slate-400 block font-semibold text-[10px]">Cmt</span>
                      <span className="text-slate-700 truncate block">{wp.sat || "Dinlenme"}</span>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-200/60 flex justify-between items-center text-xs">
                    <span className="text-slate-500">Hedef Haftalık HSR:</span>
                    <span className="font-bold text-indigo-600">{wp.targetHsr} metre</span>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-6 text-slate-400 text-xs">
                Bu oyuncu için henüz planlanmış haftalık periyotlama yok.
              </div>
            )}
          </div>

          {/* Daily training drills */}
          <div className="bg-white rounded-2xl border border-slate-100 p-5 shadow-sm space-y-4">
            <h4 className="font-bold text-slate-800 flex items-center gap-2 text-sm border-b border-slate-100 pb-3">
              <Clock size={18} className="text-emerald-500" />
              📋 Yakın Zamanlı Günlük Planlar
            </h4>
            {playerDailyPlans.length > 0 ? (
              <div className="space-y-4">
                {playerDailyPlans.map((dp) => (
                  <div key={dp.id} className="border border-slate-100 rounded-xl p-4 bg-slate-50/50 space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-slate-500 font-bold font-mono bg-white px-2 py-0.5 rounded shadow-xs">
                        {dp.date}
                      </span>
                      <span className="text-xs bg-emerald-50 text-emerald-700 font-bold px-2 py-1 rounded">
                        {dp.type}
                      </span>
                    </div>

                    <div className="text-xs space-y-2.5 bg-white p-3 rounded-lg border border-slate-100">
                      <div className="space-y-0.5">
                        <span className="font-extrabold text-indigo-700 text-[10px] uppercase block">1-) Isınma & Mobilizasyon (RAMP)</span>
                        <p className="text-slate-600 leading-normal font-medium">{dp.warmup}</p>
                      </div>
                      <div className="space-y-0.5 border-t border-slate-100 pt-1.5">
                        <span className="font-extrabold text-blue-700 text-[10px] uppercase block">2-) Core-Aktivasyon</span>
                        <p className="text-slate-600 leading-normal font-medium">{dp.coreActivation || "Belirtilmemiş"}</p>
                      </div>
                      <div className="space-y-0.5 border-t border-slate-100 pt-1.5">
                        <span className="font-extrabold text-amber-700 text-[10px] uppercase block">3-) Pliometri ve Saq</span>
                        <p className="text-slate-600 leading-normal font-medium">{dp.plyoSaq || "Belirtilmemiş"}</p>
                      </div>
                      <div className="space-y-0.5 border-t border-slate-100 pt-1.5">
                        <span className="font-extrabold text-emerald-700 text-[10px] uppercase block">4-) Direnç</span>
                        <p className="text-slate-600 leading-normal font-medium">{dp.resistance || "Belirtilmemiş"}</p>
                      </div>
                      <div className="space-y-0.5 border-t border-slate-100 pt-1.5">
                        <span className="font-extrabold text-rose-700 text-[10px] uppercase block">5-) Metabolik</span>
                        <p className="text-slate-600 leading-normal font-medium">{dp.energyProtocol || "Belirtilmemiş"}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-100 text-center text-[11px] text-slate-600">
                      <div>
                        <span className="text-slate-400 block font-medium">Hedef Mesafe</span>
                        <strong className="text-slate-800">{dp.targetDistance} m</strong>
                      </div>
                      <div>
                        <span className="text-slate-400 block font-medium">Hedef HSR</span>
                        <strong className="text-slate-800">{dp.targetHsr} m</strong>
                      </div>
                      <div>
                        <span className="text-slate-400 block font-medium">Hedef RPE</span>
                        <strong className="text-slate-800">RPE {dp.targetRpe}</strong>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6 text-slate-400 text-xs">
                Bu oyuncu için henüz planlanmış günlük idman yok.
              </div>
            )}
          </div>
        </div>

        {/* Realized Logs and Tracking Performance */}
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-100 p-5 shadow-sm space-y-4">
            <h4 className="font-bold text-slate-800 flex items-center gap-2 text-sm border-b border-slate-100 pb-3">
              <TrendingUp size={18} className="text-rose-500" />
              🏃‍♂️ Gerçekleşen İdman Yükleri ve Sporcu Tepkisi
            </h4>

            {playerLogs.length > 0 ? (
              <div className="space-y-4">
                {/* Visual bar comparing Target vs Actual for HSR and Distance */}
                {playerDailyPlans.length > 0 && (
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 space-y-3">
                    <span className="text-xs font-bold text-slate-700 block">Metrik Karşılaştırma (Hedef vs Gerçekleşen)</span>
                    
                    {/* Distance bar */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[11px]">
                        <span className="text-slate-500">Mesafe (Plan: {playerDailyPlans[0].targetDistance}m)</span>
                        <span className="font-bold text-slate-700">{playerLogs[0].actualDistance}m</span>
                      </div>
                      <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden flex">
                        <div 
                          className="bg-indigo-600 h-full rounded-full" 
                          style={{ width: `${Math.min(100, (playerLogs[0].actualDistance / playerDailyPlans[0].targetDistance) * 100)}%` }} 
                        />
                      </div>
                    </div>

                    {/* HSR bar */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[11px]">
                        <span className="text-slate-500">HSR Mesafe (Plan: {playerDailyPlans[0].targetHsr}m)</span>
                        <span className="font-bold text-slate-700">{playerLogs[0].actualHsr}m</span>
                      </div>
                      <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden flex">
                        <div 
                          className="bg-emerald-500 h-full rounded-full" 
                          style={{ width: `${Math.min(100, (playerLogs[0].actualHsr / playerDailyPlans[0].targetHsr) * 100)}%` }} 
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Historical log list */}
                <div className="space-y-2">
                  <span className="text-xs font-bold text-slate-400 block uppercase tracking-wider">Antrenman Günlükleri</span>
                  {playerLogs.map((log) => (
                    <div key={log.id} className="p-3 bg-white border border-slate-100 rounded-xl space-y-2 hover:border-slate-200 transition">
                      <div className="flex justify-between items-center text-xs">
                        <span className="font-bold text-slate-700">{log.date}</span>
                        <span className="text-[10px] bg-slate-100 text-slate-600 font-semibold px-2 py-0.5 rounded">
                          {log.rtpStage}
                        </span>
                      </div>
                      <div className="grid grid-cols-4 gap-2 text-center text-[10px] bg-slate-50 p-2 rounded">
                        <div>
                          <span className="text-slate-400 block">Toplam Mesafe</span>
                          <strong className="text-slate-700 block mt-0.5">{log.actualDistance} m</strong>
                        </div>
                        <div>
                          <span className="text-slate-400 block">Gerçekleşen HSR</span>
                          <strong className="text-slate-700 block mt-0.5">{log.actualHsr} m</strong>
                        </div>
                        <div>
                          <span className="text-slate-400 block">Seans RPE</span>
                          <strong className="text-slate-700 block mt-0.5">RPE {log.actualRpe}</strong>
                        </div>
                        <div>
                          <span className="text-slate-400 block">VAS Ağrı</span>
                          <strong className={`${log.vasPain >= 3 ? "text-rose-600 font-bold" : "text-slate-700"} block mt-0.5`}>
                            {log.vasPain} / 10
                          </strong>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center py-10 text-slate-400 text-xs bg-slate-50 rounded-xl border border-dashed border-slate-200">
                Bu oyuncu için henüz gerçekleşen idman verisi kaydedilmedi.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
