import React, { useState, useEffect } from "react";
import { Player } from "../types";
import { 
  Activity, 
  Save, 
  ThumbsUp, 
  ThumbsDown, 
  ShieldAlert, 
  BadgeCheck, 
  Zap, 
  Gauge, 
  Flame, 
  ChevronRight, 
  Scale, 
  TrendingUp, 
  Sparkles,
  Info
} from "lucide-react";

interface IsokineticTestViewProps {
  selectedPlayer: Player;
  onUpdatePlayerMetrics: (playerId: string, metrics: Partial<Player>) => void;
}

export default function IsokineticTestView({
  selectedPlayer,
  onUpdatePlayerMetrics,
}: IsokineticTestViewProps) {
  // Body weight (kg) for relative calculations
  const [bodyWeight, setBodyWeight] = useState(80);

  // --- STASYON 1: 60°/s (Maksimal Kuvvet Değerlendirmesi) ---
  const [qPeakTorqueL60, setQPeakTorqueL60] = useState(250);
  const [qPeakTorqueR60, setQPeakTorqueR60] = useState(245);
  const [hPeakTorqueL60, setHPeakTorqueL60] = useState(160);
  const [hPeakTorqueR60, setHPeakTorqueR60] = useState(155);

  // Time to Peak Torque (ms)
  const [qTimeToPeakL60, setQTimeToPeakL60] = useState(210);
  const [qTimeToPeakR60, setQTimeToPeakR60] = useState(215);
  const [hTimeToPeakL60, setHTimeToPeakL60] = useState(190);
  const [hTimeToPeakR60, setHTimeToPeakR60] = useState(195);

  // Angle of Peak Torque (derece)
  const [qAngleL60, setQAngleL60] = useState(65);
  const [qAngleR60, setQAngleR60] = useState(67);
  const [hAngleL60, setHAngleL60] = useState(35);
  const [hAngleR60, setHAngleR60] = useState(33);


  // --- STASYON 2: 180°/s (Güç ve Hız Değerlendirmesi) ---
  const [qPeakTorqueL180, setQPeakTorqueL180] = useState(170);
  const [qPeakTorqueR180, setQPeakTorqueR180] = useState(165);
  const [hPeakTorqueL180, setHPeakTorqueL180] = useState(120);
  const [hPeakTorqueR180, setHPeakTorqueR180] = useState(115);

  // Average Power (Watt)
  const [qAvgPowerL180, setQAvgPowerL180] = useState(280);
  const [qAvgPowerR180, setQAvgPowerR180] = useState(270);
  const [hAvgPowerL180, setHAvgPowerL180] = useState(190);
  const [hAvgPowerR180, setHAvgPowerR180] = useState(185);

  // Eccentric Hamstring Peak Torque (Nm) for Functional H:Q Ratio
  const [hEccPeakTorqueL180, setHEccPeakTorqueL180] = useState(165);
  const [hEccPeakTorqueR180, setHEccPeakTorqueR180] = useState(160);


  // --- STASYON 3: 300°/s (Kuvvette Devamlılık Değerlendirmesi) ---
  const [qPeakTorqueL300, setQPeakTorqueL300] = useState(110);
  const [qPeakTorqueR300, setQPeakTorqueR300] = useState(105);
  const [hPeakTorqueL300, setHPeakTorqueL300] = useState(88);
  const [hPeakTorqueR300, setHPeakTorqueR300] = useState(82);

  // Work Fatigue Index (Yorgunluk İndeksi - %)
  const [qFatigueL300, setQFatigueL300] = useState(42);
  const [qFatigueR300, setQFatigueR300] = useState(44);
  const [hFatigueL300, setHFatigueL300] = useState(45);
  const [hFatigueR300, setHFatigueR300] = useState(47);

  // Total Work (Toplam İş - Joule)
  const [qWorkL300, setQWorkL300] = useState(1200);
  const [qWorkR300, setQWorkR300] = useState(1150);
  const [hWorkL300, setHWorkL300] = useState(800);
  const [hWorkR300, setHWorkR300] = useState(780);

  const [successMsg, setSuccessMsg] = useState("");

  // Sync with selected player properties on mount
  useEffect(() => {
    setQPeakTorqueL60(selectedPlayer.quadricepsPeakTorque || 250);
    setQPeakTorqueR60(selectedPlayer.quadricepsPeakTorque ? Math.round(selectedPlayer.quadricepsPeakTorque * 0.96) : 240);
    setHPeakTorqueL60(selectedPlayer.hamstringPeakTorque || 160);
    setHPeakTorqueR60(selectedPlayer.hamstringPeakTorque ? Math.round(selectedPlayer.hamstringPeakTorque * 0.96) : 150);

    setQPeakTorqueL180(selectedPlayer.quadricepsPeakTorque180 || 170);
    setQPeakTorqueR180(selectedPlayer.quadricepsPeakTorque180 ? Math.round(selectedPlayer.quadricepsPeakTorque180 * 0.97) : 165);
    setHPeakTorqueL180(selectedPlayer.hamstringPeakTorque180 || 120);
    setHPeakTorqueR180(selectedPlayer.hamstringPeakTorque180 ? Math.round(selectedPlayer.hamstringPeakTorque180 * 0.96) : 115);

    setQPeakTorqueL300(selectedPlayer.quadricepsPeakTorque300 || 110);
    setQPeakTorqueR300(selectedPlayer.quadricepsPeakTorque300 ? Math.round(selectedPlayer.quadricepsPeakTorque300 * 0.95) : 105);
    setHPeakTorqueL300(selectedPlayer.hamstringPeakTorque300 || 88);
    setHPeakTorqueR300(selectedPlayer.hamstringPeakTorque300 ? Math.round(selectedPlayer.hamstringPeakTorque300 * 0.93) : 82);
  }, [selectedPlayer]);

  // --- LIVE MATH CALCULATIONS & RATIOS ---

  // Dynamic weights fallback
  const pWeight = bodyWeight > 0 ? bodyWeight : 80;

  // 1. Rölatif Kuvvetler (Nm/kg)
  const qRelL60 = parseFloat((qPeakTorqueL60 / pWeight).toFixed(2));
  const qRelR60 = parseFloat((qPeakTorqueR60 / pWeight).toFixed(2));
  const hRelL60 = parseFloat((hPeakTorqueL60 / pWeight).toFixed(2));
  const hRelR60 = parseFloat((hPeakTorqueR60 / pWeight).toFixed(2));

  // 2. Bilateral Asimetriler (Sol vs Sağ Farkı %)
  const maxQ60 = Math.max(qPeakTorqueL60, qPeakTorqueR60);
  const qAsym60 = maxQ60 > 0 ? parseFloat((Math.abs(qPeakTorqueL60 - qPeakTorqueR60) / maxQ60 * 100).toFixed(1)) : 0;

  const maxH60 = Math.max(hPeakTorqueL60, hPeakTorqueR60);
  const hAsym60 = maxH60 > 0 ? parseFloat((Math.abs(hPeakTorqueL60 - hPeakTorqueR60) / maxH60 * 100).toFixed(1)) : 0;

  const maxQ180 = Math.max(qPeakTorqueL180, qPeakTorqueR180);
  const qAsym180 = maxQ180 > 0 ? parseFloat((Math.abs(qPeakTorqueL180 - qPeakTorqueR180) / maxQ180 * 100).toFixed(1)) : 0;

  const maxH180 = Math.max(hPeakTorqueL180, hPeakTorqueR180);
  const hAsym180 = maxH180 > 0 ? parseFloat((Math.abs(hPeakTorqueL180 - hPeakTorqueR180) / maxH180 * 100).toFixed(1)) : 0;

  const maxQ300 = Math.max(qPeakTorqueL300, qPeakTorqueR300);
  const qAsym300 = maxQ300 > 0 ? parseFloat((Math.abs(qPeakTorqueL300 - qPeakTorqueR300) / maxQ300 * 100).toFixed(1)) : 0;

  const maxH300 = Math.max(hPeakTorqueL300, hPeakTorqueR300);
  const hAsym300 = maxH300 > 0 ? parseFloat((Math.abs(hPeakTorqueL300 - hPeakTorqueR300) / maxH300 * 100).toFixed(1)) : 0;

  // 3. H:Q Oranları (Conventional / Fonksiyonel)
  // Conventional (Con H / Con Q) @ 60°/s (Ref >= 0.60)
  const hqRatioL60 = qPeakTorqueL60 > 0 ? parseFloat((hPeakTorqueL60 / qPeakTorqueL60).toFixed(2)) : 0;
  const hqRatioR60 = qPeakTorqueR60 > 0 ? parseFloat((hPeakTorqueR60 / qPeakTorqueR60).toFixed(2)) : 0;

  // Conventional (Con H / Con Q) @ 180°/s
  const hqRatioL180 = qPeakTorqueL180 > 0 ? parseFloat((hPeakTorqueL180 / qPeakTorqueL180).toFixed(2)) : 0;
  const hqRatioR180 = qPeakTorqueR180 > 0 ? parseFloat((hPeakTorqueR180 / qPeakTorqueR180).toFixed(2)) : 0;

  // Functional (Eccentric H / Concentric Q) @ 180°/s (Ref near 1.00)
  const hqFuncL180 = qPeakTorqueL180 > 0 ? parseFloat((hEccPeakTorqueL180 / qPeakTorqueL180).toFixed(2)) : 0;
  const hqFuncR180 = qPeakTorqueR180 > 0 ? parseFloat((hEccPeakTorqueR180 / qPeakTorqueR180).toFixed(2)) : 0;

  // Conventional @ 300°/s (Ref >= 0.80)
  const hqRatioL300 = qPeakTorqueL300 > 0 ? parseFloat((hPeakTorqueL300 / qPeakTorqueL300).toFixed(2)) : 0;
  const hqRatioR300 = qPeakTorqueR300 > 0 ? parseFloat((hPeakTorqueR300 / qPeakTorqueR300).toFixed(2)) : 0;

  // 4. Fiber Tipi Tork Düşüşleri (60 -> 180°/s) - Lif Profili Göstergesi %
  const qDropL = qPeakTorqueL60 > 0 ? parseFloat((((qPeakTorqueL60 - qPeakTorqueL180) / qPeakTorqueL60) * 100).toFixed(1)) : 0;
  const qDropR = qPeakTorqueR60 > 0 ? parseFloat((((qPeakTorqueR60 - qPeakTorqueR180) / qPeakTorqueR60) * 100).toFixed(1)) : 0;

  // --- ⚙️ BİYOMEKANİK KARAR AĞACI ALGORİTMASI ---
  const evaluateBiomechanicalStatus = () => {
    const reasons: string[] = [];
    let light: "green" | "yellow" | "red" = "green";

    // 🔴 RED LIGHT (Kritik Risk / Saha Engeli)
    // - Herhangi bir asimetri > 15% VEYA Konvansiyonel H:Q @ 60 < 0.55 VEYA Yorgunluk İndeksi > 50%
    const hasRedAsymmetry = qAsym60 > 15 || hAsym60 > 15 || qAsym180 > 15 || hAsym180 > 15 || qAsym300 > 15 || hAsym300 > 15;
    const hasRedHq = hqRatioL60 < 0.55 || hqRatioR60 < 0.55;
    const hasRedFatigue = qFatigueL300 > 50 || qFatigueR300 > 50 || hFatigueL300 > 50 || hFatigueR300 > 50;

    if (qAsym60 > 15) reasons.push(`60°/s Quadriceps Asimetrisi (%${qAsym60}) kritik eşiğin (> %15) üzerindedir.`);
    if (hAsym60 > 15) reasons.push(`60°/s Hamstring Asimetrisi (%${hAsym60}) kritik eşiğin (> %15) üzerindedir.`);
    if (hqRatioL60 < 0.55) reasons.push(`Sol bacak 60°/s H:Q Konvansiyonel oranı (${hqRatioL60}) kritik sınırın (< 0.55) altında.`);
    if (hqRatioR60 < 0.55) reasons.push(`Sağ bacak 60°/s H:Q Konvansiyonel oranı (${hqRatioR60}) kritik sınırın (< 0.55) altında.`);
    if (qFatigueL300 > 50 || qFatigueR300 > 50) reasons.push(`Quadriceps Yorgunluk İndeksi kritik limiti (%50) aştı. Kas dayanıklılığı yetersiz.`);

    if (hasRedAsymmetry || hasRedHq || hasRedFatigue) {
      return {
        light: "red" as const,
        status: "🔴 KIRMIZI IŞIK (Yüksek Sakatlık Riski - Saha Onayı Yok)",
        action: "Dikkat! Kritik eklem stabilite açığı ve frapan asimetri saptandı. Sporcunun tam hacimli takım idmanlarına ve sprintlere katılımı risklidir. Kuvvet ve Fizyoterapi birimince acil izole Hamstring eksantrik yükleme ve nöral aktivasyon programı başlatılmalıdır.",
        color: "bg-rose-50 border-rose-200 text-rose-900",
        badgeColor: "bg-rose-600 text-white animate-pulse",
        reasons
      };
    }

    // 🟡 YELLOW LIGHT (Sarı Işık - Sınırda / Modifikasyon)
    // - Asimetri 10% - 15% arasında VEYA H:Q 60°/s 0.55 - 0.60 arasında VEYA Fonksiyonel H:Q < 0.85
    const hasYellowAsymmetry = (qAsym60 >= 10 && qAsym60 <= 15) || (hAsym60 >= 10 && hAsym60 <= 15) || (qAsym180 >= 10 && qAsym180 <= 15) || (hAsym180 >= 10 && hAsym180 <= 15);
    const hasYellowHq = (hqRatioL60 >= 0.55 && hqRatioL60 < 0.60) || (hqRatioR60 >= 0.55 && hqRatioR60 < 0.60);
    const hasYellowFuncHq = hqFuncL180 < 0.85 || hqFuncR180 < 0.85;

    if (hasYellowAsymmetry) reasons.push(`Eklem tork asimetrileri sınır bölgesindedir (%10 - %15). Sol/Sağ dengesizlik var.`);
    if (hasYellowHq) reasons.push(`60°/s H:Q Oranı limit sınıra yakın (0.55 - 0.60). Hamstring torku zayıf.`);
    if (hasYellowFuncHq) reasons.push(`180°/s Fonksiyonel (Eksantrik H / Konsantrik Q) oranı idealin (< 0.85) gerisinde kalıyor.`);

    if (hasYellowAsymmetry || hasYellowHq || hasYellowFuncHq) {
      return {
        light: "yellow" as const,
        status: "🟡 SARI IŞIK (Sınırlı Vize - Antrenman Kısıtlaması)",
        action: "Biyomekanik oranlar sınırda. Sporcunun yön değiştirme (COD) ve maksimal hızlanma ivmeleri %20 oranında kısıtlanmalı, kuvvet seansının sonuna ek Hamstring eksantrik (Nordic/Single leg deadlift) drilleri yerleştirilmelidir.",
        color: "bg-amber-50 border-amber-200 text-amber-900",
        badgeColor: "bg-amber-500 text-slate-950",
        reasons
      };
    }

    // 🟢 GREEN LIGHT (Oyna ve Güvenle Yükle)
    reasons.push(`Tüm bilateral asimetriler ideal güvenli sınırlar dahilindedir (< %10.0).`);
    reasons.push(`Konvansiyonel H:Q oranları (${hqRatioL60}) ideal koruyucu limitin (&ge; 0.60) üzerindedir.`);
    reasons.push(`Fonksiyonel Eksantrik H / Konsantrik Q oranları (${hqFuncL180}) tam stabilite sağlıyor (&ge; 0.85).`);
    reasons.push(`Kas yorgunluk toleransı ve rölatif kuvvetler (Sol Q: ${qRelL60} Nm/kg) elit düzey standartlarındadır.`);

    return {
      light: "green" as const,
      status: "🟢 YEŞİL IŞIK (Biyomekanik Vize Verildi - Sahaya Dönüş)",
      action: "Kusursuz diz eklem dengesi! Sporcunun Quadriceps ve Hamstring sinerjisi RTP protokolünü tamamlamıştır. Tam hacimli sportif yüklere, yüksek şiddetli sprinte ve yön değiştirmeli maç drillerine %100 onay verilmiştir.",
      color: "bg-emerald-50 border-emerald-200 text-emerald-900",
      badgeColor: "bg-emerald-600 text-white",
      reasons
    };
  };

  const decision = evaluateBiomechanicalStatus();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Persist to parent context
    onUpdatePlayerMetrics(selectedPlayer.id, {
      hqRatio: parseFloat(hqRatioL60.toFixed(2)), // Set 60°/s left as main HQ Ratio
      quadricepsPeakTorque: qPeakTorqueL60,
      hamstringPeakTorque: hPeakTorqueL60,
      quadricepsPeakTorque180: qPeakTorqueL180,
      hamstringPeakTorque180: hPeakTorqueL180,
      quadricepsPeakTorque300: qPeakTorqueL300,
      hamstringPeakTorque300: hPeakTorqueL300,
      hqRatio60: parseFloat(hqRatioL60.toFixed(2)),
      hqRatio180: parseFloat(hqRatioL180.toFixed(2)),
      hqRatio300: parseFloat(hqRatioL300.toFixed(2)),
      quad_peak_torque_bw: qRelL60, // Relative force Left
    });

    setSuccessMsg(`İzokinetik Dinamometre test verileri ve rasyoları başarıyla işlendi ve ${selectedPlayer.name} profiline kaydedildi. Karar: ${decision.status}.`);
    window.scrollTo({ top: 0, behavior: "smooth" });
    setTimeout(() => setSuccessMsg(""), 6000);
  };

  return (
    <div className="space-y-6" id="isokinetic-test-view-root">
      {/* 1. Header Information */}
      <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-xs flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="flex h-2.5 w-2.5 rounded-full bg-violet-600 animate-pulse" />
            <span className="text-xs font-black text-violet-600 uppercase tracking-widest font-mono">BİYOMEKANİK RTP ALTIN STANDARTLARI</span>
          </div>
          <h2 className="text-xl font-black text-slate-800 flex items-center gap-2">
            <Activity className="text-violet-600 h-6 w-6" />
            🔬 Çoklu Açısal Hız İzokinetik Dinamometre Test Paneli (Kuvvet-Hız Profilleme)
          </h2>
          <p className="text-xs text-slate-500 max-w-4xl leading-relaxed">
            Diz eklemi fleksiyon ve ekstansiyon kas gruplarının (Hamstring ve Quadriceps) üç farklı açısal hızdaki <strong>(60°/s, 180°/s, 300°/s)</strong> performans taraması. Biyomekanik kuvvet-hız eğrisi ve sakatlık koruma rasyoları oluşturulur.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <div className="bg-violet-50 text-violet-800 text-xs font-bold px-3.5 py-2.5 rounded-xl border border-violet-100 flex items-center gap-1.5">
            <Info size={14} />
            <span>Oyuncu: {selectedPlayer.name}</span>
          </div>

          <div className="bg-slate-100 border border-slate-200 rounded-xl p-2 flex items-center gap-2">
            <span className="text-xs font-bold text-slate-600">Sporcu Ağırlığı:</span>
            <input
              type="number"
              min="40"
              max="150"
              value={bodyWeight}
              onChange={(e) => setBodyWeight(parseInt(e.target.value) || 80)}
              className="w-16 bg-white border border-slate-300 rounded px-1.5 py-1 text-center font-bold text-xs font-mono text-slate-800"
            />
            <span className="text-xs font-bold text-slate-400">kg</span>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {successMsg && (
          <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold p-4.5 rounded-xl animate-fade-in flex items-center gap-2">
            <BadgeCheck size={18} className="text-emerald-600 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* 2. LIVE INTERACTIVE BIOMECHANICAL STATUS (TRAFFIC LIGHT) */}
        <div className={`border-2 p-6 rounded-2xl transition-all duration-300 shadow-sm ${decision.color}`} id="isokinetic-live-decision-box">
          <div className="flex items-start gap-4 flex-col sm:flex-row">
            <div className="p-3 bg-white rounded-2xl shadow-xs shrink-0 flex items-center justify-center border border-slate-100">
              <div className="flex flex-col gap-1.5 items-center">
                <span className={`h-5 w-5 rounded-full border-2 border-slate-350 ${decision.light === "red" ? "bg-rose-600 shadow-[0_0_12px_rgba(225,29,72,0.6)]" : "bg-slate-200"}`} />
                <span className={`h-5 w-5 rounded-full border-2 border-slate-350 ${decision.light === "yellow" ? "bg-amber-400 shadow-[0_0_12px_rgba(251,191,36,0.6)]" : "bg-slate-200"}`} />
                <span className={`h-5 w-5 rounded-full border-2 border-slate-350 ${decision.light === "green" ? "bg-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.6)]" : "bg-slate-200"}`} />
              </div>
            </div>

            <div className="space-y-3 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className={`text-[10px] uppercase font-black px-3.5 py-1.5 rounded-xl ${decision.badgeColor} shadow-2xs tracking-wide`}>
                  {decision.status}
                </span>
                <span className="font-extrabold text-xs text-slate-500 uppercase tracking-widest font-mono">BİYOMEKANİK ENTEGRE KARAR DESTEK MOTORU</span>
              </div>
              
              <div className="space-y-1.5">
                <h3 className="font-black text-slate-900 text-base leading-snug">Algoritmik Klinik Tavsiye & Saha Vizesi:</h3>
                <p className="text-sm font-bold text-slate-800 leading-relaxed bg-white/65 p-3.5 rounded-xl border border-white/40">
                  {decision.action}
                </p>
              </div>

              {/* Dynamic triggers display */}
              <div className="pt-2">
                <span className="text-[10px] font-black text-slate-500 uppercase tracking-wider block mb-1.5">Algoritma Karar Gerekçeleri & İnceleme:</span>
                <ul className="space-y-1 text-xs font-semibold text-slate-700">
                  {decision.reasons.map((r, i) => (
                    <li key={i} className="flex items-center gap-2">
                      <ChevronRight size={14} className="text-slate-400 shrink-0" />
                      <span>{r}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* 3. STATIONS INPUTS GRIDS */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          
          {/* STATION 1: 60°/s (MAKSİMAL KUVVET) */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xs flex flex-col justify-between overflow-hidden">
            <div className="p-5 border-b border-slate-100 bg-slate-50/50">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black text-indigo-500 uppercase tracking-wider font-mono">STASYON 1</span>
                <span className="bg-indigo-50 text-indigo-700 border border-indigo-100 text-[9px] font-mono font-bold px-2 py-0.5 rounded-md">60°/s Maksimal Kuvvet</span>
              </div>
              <h4 className="font-black text-slate-800 text-sm mt-1 flex items-center gap-1.5">
                <Gauge size={16} className="text-indigo-600" />
                Düşük Hız (60°/s) - Maks Tork
              </h4>
            </div>

            <div className="p-5 space-y-4 flex-1">
              {/* Peak Torque inputs */}
              <div className="space-y-3">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">1. Peak Torque (Nm - Tepe Tork)</span>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-600 block">Sol Quadriceps (Nm)</label>
                    <input
                      type="number"
                      value={qPeakTorqueL60}
                      onChange={(e) => setQPeakTorqueL60(parseInt(e.target.value) || 0)}
                      className="w-full text-xs font-bold font-mono bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-center animate-none"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-600 block">Sağ Quadriceps (Nm)</label>
                    <input
                      type="number"
                      value={qPeakTorqueR60}
                      onChange={(e) => setQPeakTorqueR60(parseInt(e.target.value) || 0)}
                      className="w-full text-xs font-bold font-mono bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-center"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-600 block">Sol Hamstring (Nm)</label>
                    <input
                      type="number"
                      value={hPeakTorqueL60}
                      onChange={(e) => setHPeakTorqueL60(parseInt(e.target.value) || 0)}
                      className="w-full text-xs font-bold font-mono bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-center"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-600 block">Sağ Hamstring (Nm)</label>
                    <input
                      type="number"
                      value={hPeakTorqueR60}
                      onChange={(e) => setHPeakTorqueR60(parseInt(e.target.value) || 0)}
                      className="w-full text-xs font-bold font-mono bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-center"
                    />
                  </div>
                </div>
              </div>

              {/* Time to Peak Torque inputs */}
              <div className="space-y-3 pt-2 border-t border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">2. Tepe Torka Ulaşma Süresi (ms)</span>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-medium text-slate-500 block">Sol Quad (ms)</label>
                    <input
                      type="number"
                      value={qTimeToPeakL60}
                      onChange={(e) => setQTimeToPeakL60(parseInt(e.target.value) || 0)}
                      className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2 text-center font-mono"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-medium text-slate-500 block">Sağ Quad (ms)</label>
                    <input
                      type="number"
                      value={qTimeToPeakR60}
                      onChange={(e) => setQTimeToPeakR60(parseInt(e.target.value) || 0)}
                      className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2 text-center font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Angle of Peak Torque inputs */}
              <div className="space-y-3 pt-2 border-t border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">3. Tepe Tork Açısı (Angle of PT °)</span>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-medium text-slate-500 block">Sol Quad Açı (°)</label>
                    <input
                      type="number"
                      value={qAngleL60}
                      onChange={(e) => setQAngleL60(parseInt(e.target.value) || 0)}
                      className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2 text-center font-mono"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-medium text-slate-500 block">Sağ Quad Açı (°)</label>
                    <input
                      type="number"
                      value={qAngleR60}
                      onChange={(e) => setQAngleR60(parseInt(e.target.value) || 0)}
                      className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2 text-center font-mono"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* LIVE AUTOMATIC CALCULATIONS & COMPARISONS */}
            <div className="p-4 bg-slate-900 text-slate-100 border-t border-slate-800 space-y-3">
              <span className="text-[9px] font-bold text-indigo-400 uppercase tracking-widest block font-mono">BİYOMEKANİK ANALİZ RAPORU</span>
              
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">Rölatif Sol Quad (Nm/kg):</span>
                  <div className="flex items-center gap-1.5 font-mono">
                    <strong className="text-white text-sm">{qRelL60}</strong>
                    <span className={`text-[10px] font-bold px-1 rounded ${qRelL60 >= 3.0 ? "text-emerald-400 bg-emerald-500/15" : "text-rose-400 bg-rose-500/15"}`}>
                      {qRelL60 >= 3.0 ? "ELİT" : "YETERSİZ"}
                    </span>
                  </div>
                </div>

                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">Quad Bilateral Asimetri:</span>
                  <div className="flex items-center gap-1.5 font-mono">
                    <strong className="text-white text-sm">% {qAsym60}</strong>
                    <span className={`text-[10px] font-bold px-1 rounded ${qAsym60 > 15 ? "text-rose-400 bg-rose-500/15" : qAsym60 > 10 ? "text-amber-400 bg-amber-500/15" : "text-emerald-400 bg-emerald-500/15"}`}>
                      {qAsym60 <= 10 ? "İDEAL" : qAsym60 <= 15 ? "SINIR" : "RİSK"}
                    </span>
                  </div>
                </div>

                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">Hamstring Asimetrisi:</span>
                  <div className="flex items-center gap-1.5 font-mono">
                    <strong className="text-white text-sm">% {hAsym60}</strong>
                    <span className={`text-[10px] font-bold px-1 rounded ${hAsym60 > 15 ? "text-rose-400 bg-rose-500/15" : hAsym60 > 10 ? "text-amber-400 bg-amber-500/15" : "text-emerald-400 bg-emerald-500/15"}`}>
                      {hAsym60 <= 10 ? "İDEAL" : hAsym60 <= 15 ? "SINIR" : "RİSK"}
                    </span>
                  </div>
                </div>

                <div className="flex justify-between items-center text-xs border-t border-slate-800 pt-2">
                  <span className="text-slate-400">Konvansiyonel H:Q Oranı:</span>
                  <div className="flex items-center gap-2 font-mono">
                    <span className="text-[11px]">Sol: <strong className={hqRatioL60 >= 0.60 ? "text-emerald-400" : "text-rose-400"}>{hqRatioL60}</strong></span>
                    <span className="text-[11px]">Sağ: <strong className={hqRatioR60 >= 0.60 ? "text-emerald-400" : "text-rose-400"}>{hqRatioR60}</strong></span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* STATION 2: 180°/s (PATLAYICI GÜÇ / HIZ) */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xs flex flex-col justify-between overflow-hidden">
            <div className="p-5 border-b border-slate-100 bg-slate-50/50">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black text-amber-500 uppercase tracking-wider font-mono">STASYON 2</span>
                <span className="bg-amber-50 text-amber-700 border border-amber-100 text-[9px] font-mono font-bold px-2 py-0.5 rounded-md">180°/s Patlayıcı Güç</span>
              </div>
              <h4 className="font-black text-slate-800 text-sm mt-1 flex items-center gap-1.5">
                <Zap size={16} className="text-amber-500" />
                Orta Hız (180°/s) - Güç Analizi
              </h4>
            </div>

            <div className="p-5 space-y-4 flex-1">
              {/* Torque inputs */}
              <div className="space-y-3">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">1. Konsantrik Peak Torque (Nm)</span>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-600 block">Sol Quadriceps (Nm)</label>
                    <input
                      type="number"
                      value={qPeakTorqueL180}
                      onChange={(e) => setQPeakTorqueL180(parseInt(e.target.value) || 0)}
                      className="w-full text-xs font-bold font-mono bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-center"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-600 block">Sağ Quadriceps (Nm)</label>
                    <input
                      type="number"
                      value={qPeakTorqueR180}
                      onChange={(e) => setQPeakTorqueR180(parseInt(e.target.value) || 0)}
                      className="w-full text-xs font-bold font-mono bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-center"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-600 block">Sol Hamstring (Nm)</label>
                    <input
                      type="number"
                      value={hPeakTorqueL180}
                      onChange={(e) => setHPeakTorqueL180(parseInt(e.target.value) || 0)}
                      className="w-full text-xs font-bold font-mono bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-center"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-600 block">Sağ Hamstring (Nm)</label>
                    <input
                      type="number"
                      value={hPeakTorqueR180}
                      onChange={(e) => setHPeakTorqueR180(parseInt(e.target.value) || 0)}
                      className="w-full text-xs font-bold font-mono bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-center"
                    />
                  </div>
                </div>
              </div>

              {/* Average Power inputs */}
              <div className="space-y-3 pt-2 border-t border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">2. Ortalama Mekanik Güç (Watt)</span>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-medium text-slate-500 block">Sol Quad Güç (W)</label>
                    <input
                      type="number"
                      value={qAvgPowerL180}
                      onChange={(e) => setQAvgPowerL180(parseInt(e.target.value) || 0)}
                      className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2 text-center font-mono"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-medium text-slate-500 block">Sağ Quad Güç (W)</label>
                    <input
                      type="number"
                      value={qAvgPowerR180}
                      onChange={(e) => setQAvgPowerR180(parseInt(e.target.value) || 0)}
                      className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2 text-center font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Eccentric Hamstring (For Functional H:Q) */}
              <div className="space-y-3 pt-2 border-t border-slate-100">
                <span className="text-[10px] font-bold text-amber-600 uppercase tracking-wider block">3. Eksantrik Hamstring Peak Torque (Nm)</span>
                <p className="text-[9px] text-slate-400 -mt-2 leading-relaxed">
                  Sprint frenlemesinde eklem hasar riskini (ACL / Hamstring yırtığı) azaltan en kritik mekanizmadır.
                </p>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-600 block">Sol Eksantrik H (Nm)</label>
                    <input
                      type="number"
                      value={hEccPeakTorqueL180}
                      onChange={(e) => setHEccPeakTorqueL180(parseInt(e.target.value) || 0)}
                      className="w-full text-xs bg-amber-50/50 border border-amber-200 rounded-lg p-2 text-center font-mono font-bold"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-600 block">Sağ Eksantrik H (Nm)</label>
                    <input
                      type="number"
                      value={hEccPeakTorqueR180}
                      onChange={(e) => setHEccPeakTorqueR180(parseInt(e.target.value) || 0)}
                      className="w-full text-xs bg-amber-50/50 border border-amber-200 rounded-lg p-2 text-center font-mono font-bold"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* LIVE AUTOMATIC CALCULATIONS & COMPARISONS */}
            <div className="p-4 bg-slate-900 text-slate-100 border-t border-slate-800 space-y-3">
              <span className="text-[9px] font-bold text-amber-400 uppercase tracking-widest block font-mono">GÜÇ & PATLAYICILIK RAPORU</span>
              
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">Hız/Tork Düşüş Hızı (60&rarr;180):</span>
                  <div className="flex items-center gap-1.5 font-mono text-[11px] text-slate-200">
                    <span>Sol: <strong>%{qDropL}</strong></span>
                    <span>Sağ: <strong>%{qDropR}</strong></span>
                  </div>
                </div>

                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">Quad Bilateral Asimetri:</span>
                  <div className="flex items-center gap-1.5 font-mono">
                    <strong className="text-white text-sm">% {qAsym180}</strong>
                    <span className={`text-[10px] font-bold px-1 rounded ${qAsym180 > 15 ? "text-rose-400 bg-rose-500/15" : "text-emerald-400 bg-emerald-500/15"}`}>
                      {qAsym180 <= 10 ? "UYGUN" : qAsym180 <= 15 ? "SINIR" : "KRİTİK"}
                    </span>
                  </div>
                </div>

                <div className="flex justify-between items-center text-xs border-t border-slate-800 pt-2">
                  <span className="text-amber-300 font-extrabold">Fonksiyonel H:Q Oranı (Ecc H / Con Q):</span>
                  <div className="flex items-center gap-2 font-mono">
                    <span className="text-[11px]">Sol: <strong className={hqFuncL180 >= 0.85 ? "text-emerald-400" : "text-amber-400"}>{hqFuncL180}</strong></span>
                    <span className="text-[11px]">Sağ: <strong className={hqFuncR180 >= 0.85 ? "text-emerald-400" : "text-amber-400"}>{hqFuncR180}</strong></span>
                  </div>
                </div>

                <div className="text-[9px] text-slate-400 leading-normal bg-amber-500/5 p-1.5 rounded border border-amber-500/10">
                  ℹ️ <strong>Hedef:</strong> Hızlı testlerde fonksiyonel oran <strong>1.00&apos;e (1:1)</strong> ne kadar yakınsa, ham sprint deselerasyon koruması o kadar mükemmeldir.
                </div>
              </div>
            </div>
          </div>

          {/* STATION 3: 300°/s (KUVVETTE DEVAMLILIK) */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xs flex flex-col justify-between overflow-hidden">
            <div className="p-5 border-b border-slate-100 bg-slate-50/50">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black text-rose-500 uppercase tracking-wider font-mono">STASYON 3</span>
                <span className="bg-rose-50 text-rose-700 border border-rose-100 text-[9px] font-mono font-bold px-2 py-0.5 rounded-md">300°/s Kuvvette Devamlılık</span>
              </div>
              <h4 className="font-black text-slate-800 text-sm mt-1 flex items-center gap-1.5">
                <Flame size={16} className="text-rose-500" />
                Yüksek Hız (300°/s) - Dayanıklılık
              </h4>
            </div>

            <div className="p-5 space-y-4 flex-1">
              {/* Torque inputs */}
              <div className="space-y-3">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">1. Peak Torque (Nm - Tepe Torku)</span>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-600 block">Sol Quadriceps (Nm)</label>
                    <input
                      type="number"
                      value={qPeakTorqueL300}
                      onChange={(e) => setQPeakTorqueL300(parseInt(e.target.value) || 0)}
                      className="w-full text-xs font-bold font-mono bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-center"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-600 block">Sağ Quadriceps (Nm)</label>
                    <input
                      type="number"
                      value={qPeakTorqueR300}
                      onChange={(e) => setQPeakTorqueR300(parseInt(e.target.value) || 0)}
                      className="w-full text-xs font-bold font-mono bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-center"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-600 block">Sol Hamstring (Nm)</label>
                    <input
                      type="number"
                      value={hPeakTorqueL300}
                      onChange={(e) => setHPeakTorqueL300(parseInt(e.target.value) || 0)}
                      className="w-full text-xs font-bold font-mono bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-center"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-600 block">Sağ Hamstring (Nm)</label>
                    <input
                      type="number"
                      value={hPeakTorqueR300}
                      onChange={(e) => setHPeakTorqueR300(parseInt(e.target.value) || 0)}
                      className="w-full text-xs font-bold font-mono bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-center"
                    />
                  </div>
                </div>
              </div>

              {/* Work Fatigue Index inputs */}
              <div className="space-y-3 pt-2 border-t border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block font-mono">2. Yorgunluk İndeksi (Fatigue % - Hedef &lt; 50%)</span>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-600 block">Sol Quad Yorg. (%)</label>
                    <input
                      type="number"
                      value={qFatigueL300}
                      onChange={(e) => setQFatigueL300(parseInt(e.target.value) || 0)}
                      className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2 text-center font-mono font-extrabold text-rose-700"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-600 block">Sağ Quad Yorg. (%)</label>
                    <input
                      type="number"
                      value={qFatigueR300}
                      onChange={(e) => setQFatigueR300(parseInt(e.target.value) || 0)}
                      className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2 text-center font-mono font-extrabold text-rose-700"
                    />
                  </div>
                </div>
              </div>

              {/* Total Work inputs */}
              <div className="space-y-3 pt-2 border-t border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">3. Toplam Yapılan İş (Total Work - Joule)</span>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-medium text-slate-500 block">Sol Quad İş (J)</label>
                    <input
                      type="number"
                      value={qWorkL300}
                      onChange={(e) => setQWorkL300(parseInt(e.target.value) || 0)}
                      className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2 text-center font-mono"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-medium text-slate-500 block">Sağ Quad İş (J)</label>
                    <input
                      type="number"
                      value={qWorkR300}
                      onChange={(e) => setQWorkR300(parseInt(e.target.value) || 0)}
                      className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2 text-center font-mono"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* LIVE AUTOMATIC CALCULATIONS & COMPARISONS */}
            <div className="p-4 bg-slate-900 text-slate-100 border-t border-slate-800 space-y-3">
              <span className="text-[9px] font-bold text-rose-400 uppercase tracking-widest block font-mono">DAYANIKLILIK & KONDİSYON RAPORU</span>
              
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">Quad Bilateral Asimetri (300°/s):</span>
                  <div className="flex items-center gap-1.5 font-mono">
                    <strong className="text-white text-sm">% {qAsym300}</strong>
                    <span className={`text-[10px] font-bold px-1 rounded ${qAsym300 > 10 ? "text-amber-400 bg-amber-500/15" : "text-emerald-400 bg-emerald-500/15"}`}>
                      {qAsym300 <= 10 ? "STABİL" : "SAPMA"}
                    </span>
                  </div>
                </div>

                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">Hamstring Asimetrisi (300°/s):</span>
                  <div className="flex items-center gap-1.5 font-mono">
                    <strong className="text-white text-sm">% {hAsym300}</strong>
                    <span className={`text-[10px] font-bold px-1 rounded ${hAsym300 > 10 ? "text-amber-400 bg-amber-500/15" : "text-emerald-400 bg-emerald-500/15"}`}>
                      {hAsym300 <= 10 ? "STABİL" : "SAPMA"}
                    </span>
                  </div>
                </div>

                <div className="flex justify-between items-center text-xs border-t border-slate-800 pt-2">
                  <span className="text-slate-400">Konvansiyonel H:Q Oranı (300°/s):</span>
                  <div className="flex items-center gap-2 font-mono">
                    <span className="text-[11px]">Sol: <strong className={hqRatioL300 >= 0.80 ? "text-emerald-400" : "text-rose-400"}>{hqRatioL300}</strong></span>
                    <span className="text-[11px]">Sağ: <strong className={hqRatioR300 >= 0.80 ? "text-emerald-400" : "text-rose-400"}>{hqRatioR300}</strong></span>
                  </div>
                </div>

                <div className="flex justify-between items-center text-xs">
                  <span className="text-rose-400 font-bold">Maksimum Yorgunluk Düşüşü:</span>
                  <span className="font-mono text-sm font-black text-white">
                    % {Math.max(qFatigueL300, qFatigueR300, hFatigueL300, hFatigueR300)}
                  </span>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* 4. SUMMARY / REFERENCE INFORMATION */}
        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-xs space-y-4">
          <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
            <h3 className="text-sm font-black text-slate-800 flex items-center gap-2">
              <Scale className="text-violet-600 animate-pulse" size={18} />
              ⚖️ İzokinetik Çoklu Açısal Hız & RTP Klinik Karar Kriterleri Özeti
            </h3>
            <span className="text-[10px] font-mono text-slate-400">Analiz Modülü v3.5</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 text-xs">
            <div className="border border-indigo-150 bg-indigo-50/10 p-4 rounded-xl space-y-2">
              <span className="text-indigo-900 font-extrabold flex items-center gap-1.5">
                <Gauge size={14} className="text-indigo-600" />
                60°/s Maksimal Kuvvet Standardı
              </span>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                Yavaş hızda <strong>Quadriceps Peak Torque &ge; 3.0 Nm/kg</strong> (Rölatif Kuvvet) spora özgü normdur. Konvansiyonel H:Q oranı <strong>&ge; 0.60</strong> bacak ön-arka mekanik dengesini teyit eder.
              </p>
            </div>

            <div className="border border-amber-150 bg-amber-50/10 p-4 rounded-xl space-y-2">
              <span className="text-amber-900 font-extrabold flex items-center gap-1.5">
                <Zap size={14} className="text-amber-600" />
                180°/s Patlayıcı Güç Standardı
              </span>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                Hızlı koşu mekaniğinde hamstringin koruyucu frenleme potansiyelini ölçer. Ortalama mekanik güç izlenir. <strong>Fonksiyonel Oranın (Eksantrik H / Konsantrik Q) &ge; 0.85</strong> olması hayati önemdedir.
              </p>
            </div>

            <div className="border border-rose-150 bg-rose-50/10 p-4 rounded-xl space-y-2">
              <span className="text-rose-900 font-extrabold flex items-center gap-1.5">
                <Flame size={14} className="text-rose-600" />
                300°/s Kuvvette Devamlılık Standardı
              </span>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                Yorulma indeksine odaklanır. 15-20 tekrarlık set sonunda <strong>Work Fatigue Index %50&apos;nin altında</strong> kalmalıdır. %50 üstü yorulma, maç sonlarında akut sakatlanma eğilimi demektir.
              </p>
            </div>
          </div>
        </div>

        {/* 5. SUBMIT ACTIONS */}
        <div className="flex items-center justify-end pt-2">
          <button
            type="submit"
            className="w-full md:w-auto md:px-10 bg-violet-600 hover:bg-violet-700 text-white font-extrabold py-4 rounded-xl transition shadow-sm flex items-center justify-center gap-2 text-sm cursor-pointer"
          >
            <Save size={18} />
            İzokinetik Test Verilerini Hesapla, Profil Güncelle & Kaydet
          </button>
        </div>
      </form>
    </div>
  );
}
