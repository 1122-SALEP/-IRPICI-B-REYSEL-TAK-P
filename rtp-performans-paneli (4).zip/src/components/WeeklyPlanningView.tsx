import React, { useState } from "react";
import { Player, WeeklyPlan } from "../types";
import { Calendar, Save, Trash2, Milestone, ArrowRight } from "lucide-react";

interface WeeklyPlanningViewProps {
  selectedPlayer: Player;
  weeklyPlans: WeeklyPlan[];
  onAddWeeklyPlan: (plan: Omit<WeeklyPlan, "id" | "createdAt">) => void;
  onDeleteWeeklyPlan: (id: string) => void;
}

export default function WeeklyPlanningView({
  selectedPlayer,
  weeklyPlans,
  onAddWeeklyPlan,
  onDeleteWeeklyPlan,
}: WeeklyPlanningViewProps) {
  const [weekNo, setWeekNo] = useState("2026-Haziran / Hafta 4 - RTP Faz 3");
  const [genelOdak, setGenelOdak] = useState("Kuvvet & Hipertrofi");
  
  const [pzt, setPzt] = useState("Gym: Eksantrik Odak + Saha: Doğrusal Koşular");
  const [sal, setSal] = useState("Saha: Geniş Alan Oyunları (Hedef Yüksek Mesafe)");
  const [car, setCar] = useState("RECOVERY / Klinik Restorasyon");
  const [per, setPer] = useState("Gym: Güç/RFD + Saha: Dar Alan Oyunları (İvmelenme)");
  const [cum, setCum] = useState("Saha: Taktik + Sprint Aktivasyonu");
  const [cts, setCts] = useState("MAÇGÜNÜ / Maksimal Yüklenme Simülasyonu");
  const [paz, setPaz] = useState("OFF / Dinlenme");
  
  const [targetHsr, setTargetHsr] = useState(1500);
  const [successMsg, setSuccessMsg] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!weekNo.trim()) return;

    onAddWeeklyPlan({
      playerId: selectedPlayer.id,
      weekNo,
      focus: genelOdak,
      mon: pzt,
      tue: sal,
      wed: car,
      thu: per,
      fri: cum,
      sat: cts,
      sun: paz,
      targetHsr,
    });

    setSuccessMsg("Haftalık periyotlama planı başarıyla kaydedildi!");
    setTimeout(() => setSuccessMsg(""), 4000);
  };

  const playerPlans = weeklyPlans.filter(p => p.playerId === selectedPlayer.id);

  return (
    <div className="space-y-6" id="weekly-planning-view-root">
      {/* View Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
        <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
          <Calendar className="text-indigo-600 h-6 w-6" />
          🗓️ Haftalık Mikroçevrim (Periyotlama) Tasarımı
        </h2>
        <p className="text-xs text-slate-500 mt-1">
          {selectedPlayer.name} için önünüzdeki 7 günlük yüklenme ve adaptasyon stratejisini belirleyin.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Form Column */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
          <form onSubmit={handleSubmit} className="space-y-5">
            {successMsg && (
              <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold p-4 rounded-xl animate-fade-in flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-emerald-500" />
                {successMsg}
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-slate-600 uppercase block mb-1">Hafta Tanımı / Başlığı</label>
                <input
                  type="text"
                  value={weekNo}
                  onChange={(e) => setWeekNo(e.target.value)}
                  placeholder="Örn: 2026-Haziran / Hafta 2 - RTP Faz 2"
                  className="w-full text-sm bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-slate-800 focus:outline-hidden focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600 uppercase block mb-1">Haftalık Ana Odak</label>
                <select
                  value={genelOdak}
                  onChange={(e) => setGenelOdak(e.target.value)}
                  className="w-full text-sm bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-slate-800 focus:outline-hidden focus:border-indigo-500"
                >
                  <option value="Kuvvet & Hipertrofi">Kuvvet & Hipertrofi</option>
                  <option value="Nöromüsküler Güç / Hız">Nöromüsküler Güç / Hız</option>
                  <option value="Aerobik Kapasite / Yo-Yo">Aerobik Kapasite / Yo-Yo</option>
                  <option value="Saha Taktik / Düşük Yük">Saha Taktik / Düşük Yük</option>
                  <option value="RTP - Klinik Aşama">RTP - Klinik Aşama</option>
                </select>
              </div>
            </div>

            <div className="border-t border-slate-100 pt-4 space-y-4">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Günlük Yüklenme Stratejisi Notları</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-600">Pazartesi</label>
                  <input
                    type="text"
                    value={pzt}
                    onChange={(e) => setPzt(e.target.value)}
                    className="w-full text-sm bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-800"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-600">Salı</label>
                  <input
                    type="text"
                    value={sal}
                    onChange={(e) => setSal(e.target.value)}
                    className="w-full text-sm bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-800"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-600">Çarşamba</label>
                  <input
                    type="text"
                    value={car}
                    onChange={(e) => setCar(e.target.value)}
                    className="w-full text-sm bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-800"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-600">Perşembe</label>
                  <input
                    type="text"
                    value={per}
                    onChange={(e) => setPer(e.target.value)}
                    className="w-full text-sm bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-800"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-600">Cuma</label>
                  <input
                    type="text"
                    value={cum}
                    onChange={(e) => setCum(e.target.value)}
                    className="w-full text-sm bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-800"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-600">Cumartesi</label>
                  <input
                    type="text"
                    value={cts}
                    onChange={(e) => setCts(e.target.value)}
                    className="w-full text-sm bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-800"
                  />
                </div>
                <div className="space-y-1 md:col-span-2">
                  <label className="text-xs font-semibold text-slate-600">Pazar</label>
                  <input
                    type="text"
                    value={paz}
                    onChange={(e) => setPaz(e.target.value)}
                    className="w-full text-sm bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-800"
                  />
                </div>
              </div>
            </div>

            <div className="border-t border-slate-100 pt-4 space-y-2">
              <label className="text-xs font-bold text-slate-600 uppercase block">Hedef Toplam Haftalık HSR (Metre)</label>
              <input
                type="number"
                min="0"
                max="10000"
                step="100"
                value={targetHsr}
                onChange={(e) => setTargetHsr(parseInt(e.target.value) || 0)}
                className="w-full text-xs font-bold font-mono bg-white border border-slate-200 rounded-lg p-2.5 text-center"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-xl shadow-xs transition flex items-center justify-center gap-2 text-sm"
            >
              <Save size={18} />
              Haftalık Planı Kaydet
            </button>
          </form>
        </div>

        {/* History Column */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm space-y-4">
          <h3 className="font-bold text-slate-800 text-sm border-b border-slate-100 pb-3 flex items-center gap-2">
            <Milestone size={18} className="text-slate-500" />
            Kayıtlı Haftalık Planlar
          </h3>

          {playerPlans.length > 0 ? (
            <div className="space-y-3 overflow-y-auto max-h-[500px] pr-1">
              {playerPlans.map((plan) => (
                <div key={plan.id} className="p-3 bg-slate-50 border border-slate-100 rounded-xl space-y-2 relative group">
                  <button
                    onClick={() => onDeleteWeeklyPlan(plan.id)}
                    className="absolute right-2 top-2 p-1 text-slate-400 hover:text-rose-500 rounded-lg transition"
                    title="Planı Sil"
                  >
                    <Trash2 size={15} />
                  </button>
                  <div className="pr-6">
                    <span className="text-[10px] bg-indigo-100 text-indigo-700 font-bold px-1.5 py-0.5 rounded">
                      {plan.focus}
                    </span>
                    <h4 className="text-xs font-bold text-slate-800 mt-1 line-clamp-1">{plan.weekNo}</h4>
                    <span className="text-[10px] text-slate-400 block mt-0.5">Hedef HSR: {plan.targetHsr}m</span>
                  </div>

                  <div className="text-[10px] text-slate-500 border-t border-slate-200/50 pt-2 space-y-1">
                    <p className="truncate"><strong>Pzt:</strong> {plan.mon}</p>
                    <p className="truncate"><strong>Sal:</strong> {plan.tue}</p>
                    <p className="truncate"><strong>Cmt:</strong> {plan.sat}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-10 text-slate-400 text-xs">
              Kayıtlı haftalık plan bulunamadı.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
